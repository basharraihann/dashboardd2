{{--
Form memo bersama untuk halaman CREATE dan EDIT.
- create : @include('memo._form') (tanpa $memo)
- edit : @include('memo._form', ['memo' => $memo]) (dengan $memo)
Data dari controller: $pegawaiList, $makOptions, $makOutstanding, $nomorBerikutnya (create).
Mau ubah form memo? Cukup ubah file ini.
--}}

@if ($errors->any())
    <div
        class="flex gap-2.5 bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-xl mb-5 animate-[fadeIn_.2s_ease-out]">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24"
            stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round"
                d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
        </svg>
        <ul class="list-disc list-inside space-y-0.5">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div
    class="flex gap-2.5 bg-blue-50/70 border border-blue-100 text-blue-700 text-xs sm:text-sm px-4 py-3 rounded-xl mb-6">
    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24"
        stroke="currentColor" stroke-width="2">
        <path stroke-linecap="round" stroke-linejoin="round"
            d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
    </svg>
    <p>Nomor memo di sini gak nempel ke agenda perjalanan dinas manapun — cocok buat keperluan lain yang
        tetap butuh nomor urut memo resmi.</p>
</div>

@php
    // ----- Mode: edit bila $memo dikirim, selain itu create -----
    $memo = $memo ?? null;
    $isEdit = $memo !== null;

    $nomorBerikutnya = $nomorBerikutnya ?? null;
    $makOptions = $makOptions ?? collect();
    $makOutstanding = $makOutstanding ?? [];
    $makSisaEfektif = $makSisaEfektif ?? [];

    // ----- Daftar pegawai per peran -----
    $ppkList = $pegawaiList->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'PPK'))->values();
    $bendaharaList = $pegawaiList->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'Bendahara'))->values();
    $pjList = $pegawaiList->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'Penanggung Jawab Kegiatan'))->values();
    $petugasVerifikasiList = $pegawaiList->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'Petugas Verifikasi'))->values();

    // ----- Nilai awal: old() > data memo (edit) > default (create) -----
    $nomorMemo = old('nomor_memo', $isEdit ? $memo->nomor_memo : ($nomorBerikutnya['nomor'] ?? ''));
    $currentJenis = old('jenis_memo', $isEdit ? $memo->jenis_memo : null);
    // Jenis yang diketik manual tersimpan sebagai kategori "lainnya" + teks di jenis_manual.
    // Di kotak isian yang ditampilkan adalah teks aslinya.
    $jenisManual = old('jenis_manual', $isEdit ? $memo->jenis_manual : null);
    $currentJenisInput = ($currentJenis === 'lainnya' && filled($jenisManual)) ? $jenisManual : $currentJenis;
    $tanggalMemo = old('tanggal_memo', $isEdit ? optional($memo->tanggal_memo)->format('Y-m-d') : now()->toDateString());
    $uraianKegiatan = old('uraian_kegiatan', $isEdit ? $memo->uraian_kegiatan : null);
    $nominalAwal = old('nominal', $isEdit ? (int) round((float) $memo->nominal) : null);
    $currentMak = old('mak', $isEdit ? $memo->mak : null);
    $sel = fn(string $field) => old($field, $isEdit ? $memo->{$field} : null);
    $currentTipe = old('tipe_pembayaran', $isEdit ? ($memo->tipe_pembayaran ?? 'ls') : 'ls');

    // ----- MAK -----
    $makAdaDiDaftar = $makOptions->contains('mak', $currentMak);
    $tampilkanManual = $makOptions->isEmpty() || ($currentMak && !$makAdaDiDaftar);

    // "Payung" = MAK tanpa kode belanja (segmen ke-6).
    // Contoh: 7458.ABR.006.075.EE.524111 -> payung 7458.ABR.006.075.EE
    $makGroups = $makOptions
        ->sortBy('mak')
        ->groupBy(fn($o) => \Illuminate\Support\Str::beforeLast($o->mak, '.'));

    $currentOpt = $makOptions->firstWhere('mak', $currentMak);
    $currentLabel = $currentOpt
        ? \Illuminate\Support\Str::afterLast($currentOpt->mak, '.') . ' — ' . $currentOpt->uraian_belanja
        : ($tampilkanManual && $currentMak ? 'Ketik manual (belum ada di daftar)' : '');

    // ----- Khusus edit: memo bertanggal sebelum/sama dengan tanggal laporan FA dianggap sudah masuk
    //       realisasi FA, jadi nominalnya sendiri dikembalikan ke sisa (agar tidak muncul peringatan palsu).
    $perTanggalFa = $makOptions->max('per_tanggal');
    $memoSudahDiFa = $isEdit
        && $perTanggalFa
        && $memo->tanggal_memo
        && $memo->tanggal_memo->toDateString() <= \Carbon\Carbon::parse($perTanggalFa)->toDateString();
@endphp

<div class="grid grid-cols-1 min-[1180px]:grid-cols-2 gap-6 items-start">

    <form action="{{ $isEdit ? route('memo.update', $memo->id) : route('memo.store') }}" method="POST"
        class="space-y-5 min-w-0">
        @csrf
        @if ($isEdit)
            @method('PUT')
        @endif

        {{-- ===== Section: Informasi Memo ===== --}}
        <div
            class="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow  p-5 sm:p-6">
            <div class="flex items-center gap-2.5 mb-6">
                <div class="h-8 w-8 rounded-lg bg-blue-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-blue-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <div>
                    <h3 class="text-sm font-semibold text-gray-800">Informasi Memo</h3>
                    <p class="text-xs text-gray-400">Nomor, jenis, tanggal, dan uraian kegiatan</p>
                </div>
            </div>

            <div class="space-y-5">
                <!-- Nomor Memo -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">
                        Nomor Memo <span class="text-red-400">*</span>
                    </label>
                    <div class="flex flex-col sm:flex-row gap-2">
                        <input type="text" id="nomor-memo-input" name="nomor_memo" value="{{ $nomorMemo }}" required
                            placeholder="325/LS.D1.PPK/KU.00/09/2026"
                            class="flex-1 min-w-0 border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm font-mono tracking-tight focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                        @unless ($isEdit)
                            <button type="button" id="btn-ambil-memo"
                                class="flex-shrink-0 inline-flex items-center justify-center gap-1.5 border border-blue-200 text-blue-600 hover:bg-blue-50 active:scale-[0.97] font-semibold px-3.5 py-2.5 rounded-xl text-xs transition-all disabled:opacity-60 disabled:cursor-not-allowed">
                                <svg xmlns="http://www.w3.org/2000/svg" id="icon-ambil-memo"
                                    class="h-3.5 w-3.5 transition-transform" fill="none" viewBox="0 0 24 24"
                                    stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                </svg>
                                <span id="label-ambil-memo">Ambil Nomor Memo</span>
                            </button>
                        @endunless
                    </div>
                    @unless ($isEdit)
                        <p class="text-xs text-gray-400 mt-1.5">
                            Format ekor (setelah angka) niru nomor terakhir yang dipakai — boleh diubah manual
                            kalau beda.
                        </p>
                    @endunless
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4"> <!-- Tipe Pembayaran -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">
                            Tipe Pembayaran <span class="text-red-400">*</span>
                        </label>
                        <div class="relative">
                            {{-- Dipilih dari daftar ATAU diketik manual (lihat data-allow-custom di searchable.js).
                            Nilai ketikan dikirim lewat option data-custom; maks. 20 karakter (kolom DB). --}}
                            <select name="tipe_pembayaran" id="tipe-pembayaran" required data-allow-custom="1"
                                data-maxlength="20" data-placeholder="Pilih atau ketik sendiri..."
                                class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                                @foreach (\App\Models\MemoEntry::TIPE_PEMBAYARAN as $value => $label)
                                    <option value="{{ $value }}" @selected($currentTipe === $value)>
                                        {{ \Illuminate\Support\Str::of($label)->afterLast('(')->before(')') }} —
                                        {{ \Illuminate\Support\Str::of($label)->after('Permintaan ')->before(' (') }}
                                    </option>
                                @endforeach
                                @if ($currentTipe && !array_key_exists($currentTipe, \App\Models\MemoEntry::TIPE_PEMBAYARAN))
                                    <option value="{{ $currentTipe }}" data-custom selected>{{ $currentTipe }}</option>
                                @endif
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>

                    <!-- Jenis Memo -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">Jenis
                            Memo <span class="text-red-400">*</span></label>
                        <div class="relative">
                            <select name="jenis_memo" id="jenis-memo" required data-allow-custom="1"
                                data-maxlength="100" data-placeholder="Pilih atau ketik sendiri..."
                                class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                                <option value="" disabled {{ $currentJenisInput ? '' : 'selected' }}>— Pilih —</option>
                                @foreach (\App\Models\MemoEntry::JENIS as $value => $label)
                                    <option value="{{ $value }}" @selected($currentJenisInput === $value)>{{ $label }}
                                    </option>
                                @endforeach
                                @if ($currentJenisInput && !array_key_exists($currentJenisInput, \App\Models\MemoEntry::JENIS))
                                    <option value="{{ $currentJenisInput }}" data-custom selected>{{ $currentJenisInput }}
                                    </option>
                                @endif
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>

                    <!-- Tanggal -->
                    <div>
                        <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">
                            Tanggal Memo <span class="text-red-400">*</span>
                        </label>
                        <input type="date" name="tanggal_memo" value="{{ $tanggalMemo }}" required
                            class="w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                    </div>
                </div>

                <!-- Preview "Hal" di PDF -->
                <p class="text-xs text-gray-400 -mt-2">
                    Hal di PDF: <span id="preview-hal" class="font-medium text-gray-600"></span>
                </p>

                <!-- Uraian -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">Nama/Uraian
                        Kegiatan <span class="text-red-400">*</span></label>
                    <input type="text" name="uraian_kegiatan" value="{{ $uraianKegiatan }}" required
                        placeholder="Keperluan memo ini"
                        class="w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition placeholder:text-gray-300">
                </div>

                <!-- Perlu Nominatif -->
                @php
                    $perluNominatif = (bool) old('perlu_nominatif', $isEdit ? $memo->perlu_nominatif : false);
                    $jumlahNominatif = $isEdit ? $memo->nominatifs()->count() : 0;
                    $kunciCentang = $jumlahNominatif > 0;
                    $jenisNominatif = old('jenis_nominatif');
                @endphp
                <div x-data="{ perlu: @js($perluNominatif || $kunciCentang), jenis: @js($jenisNominatif) }"
                    class="space-y-3">
                    {{-- Kalau sudah ada nominatif, checkbox dikunci aktif dan nilai 1 dikirim lewat hidden.
                    (Checkbox disabled tidak ikut terkirim, jadi hidden ini yang jadi sumber nilai.) --}}
                    <input type="hidden" name="perlu_nominatif" value="{{ $kunciCentang ? 1 : 0 }}">
                    <label @class([
                        'flex items-start gap-3 border border-gray-200 rounded-xl px-3.5 py-3 transition',
                        'cursor-pointer hover:bg-gray-50' => !$kunciCentang,
                        'bg-gray-50 cursor-not-allowed' => $kunciCentang,
                    ])>
                        <input type="checkbox" name="perlu_nominatif" value="1" x-model="perlu" @disabled($kunciCentang)
                            class="mt-0.5 h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-200">
                        <span>
                            <span class="block text-sm font-medium text-gray-700">Memo ini perlu nominatif</span>
                            <span class="block text-xs text-gray-400 mt-0.5">
                                Kalau dicentang, memo baru bisa dikirim ke Keuangan setelah minimal satu nominatif
                                dibuat.
                            </span>
                            @if ($kunciCentang)
                                <span class="block text-xs text-amber-600 mt-1">
                                    Sudah ada {{ $jumlahNominatif }} nominatif, centang ini tidak bisa dilepas.
                                </span>
                            @endif
                        </span>
                    </label>
                    @error('perlu_nominatif')
                        <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                    @enderror

                    {{-- Pilihan jenis: muncul setelah dicentang. Radio disabled saat disembunyikan,
                    jadi tidak ikut terkirim. Disembunyikan total kalau nominatif sudah ada. --}}
                    @unless ($kunciCentang)
                        <div x-show="perlu" x-cloak x-transition.opacity class="pl-1">
                            <p class="text-xs font-semibold text-gray-500 mb-2 tracking-wide uppercase">
                                Mau buat nominatif apa?
                            </p>
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                <label
                                    class="flex items-start gap-3 border rounded-xl px-3.5 py-3 cursor-pointer transition"
                                    :class="jenis === 'honorarium' ? 'border-blue-400 bg-blue-50/60 ring-2 ring-blue-100' :
                                            'border-gray-200 hover:bg-gray-50'">
                                    <input type="radio" name="jenis_nominatif" value="honorarium" x-model="jenis"
                                        :disabled="!perlu"
                                        class="mt-0.5 h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-200">
                                    <span>
                                        <span class="block text-sm font-medium text-gray-700">Honorarium</span>
                                        <span class="block text-xs text-gray-400 mt-0.5">Daftar narasumber, honor per
                                            OJ, pajak per orang.</span>
                                    </span>
                                </label>

                                <label
                                    class="flex items-start gap-3 border rounded-xl px-3.5 py-3 cursor-pointer transition"
                                    :class="jenis === 'custom' ? 'border-blue-400 bg-blue-50/60 ring-2 ring-blue-100' :
                                            'border-gray-200 hover:bg-gray-50'">
                                    <input type="radio" name="jenis_nominatif" value="custom" x-model="jenis"
                                        :disabled="!perlu"
                                        class="mt-0.5 h-4 w-4 border-gray-300 text-blue-600 focus:ring-blue-200">
                                    <span>
                                        <span class="block text-sm font-medium text-gray-700">Custom</span>
                                        <span class="block text-xs text-gray-400 mt-0.5">Item bebas dengan PPN, PPh 22,
                                            dan PPh 23.</span>
                                    </span>
                                </label>
                            </div>
                            <p class="text-xs text-gray-400 mt-2">
                                Belum yakin? Biarkan kosong, nanti ditanya lagi setelah memo disimpan.
                            </p>
                            @error('jenis_nominatif')
                                <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                            @enderror
                        </div>
                    @endunless
                </div>
            </div>
        </div>

        {{-- ===== Section: PIC & Penanggung Jawab ===== --}}
        <div
            class="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow  p-5 sm:p-6">
            <div class="flex items-center gap-2.5 mb-6">
                <div class="h-8 w-8 rounded-lg bg-indigo-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-indigo-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-1.13a4 4 0 100-8 4 4 0 000 8zm6 3c0-1.657-3.134-3-7-3s-7 1.343-7 3v2h14v-2z" />
                    </svg>
                </div>
                <div>
                    <h3 class="text-sm font-semibold text-gray-800">PIC &amp; Penanggung Jawab</h3>
                    <p class="text-xs text-gray-400">Pegawai yang bertanggung jawab atas memo ini</p>
                </div>
            </div>

            <div class="space-y-4">
                <!-- PIC -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">PIC
                        <span class="text-red-400">*</span></label>
                    <div class="relative">
                        <select name="pic_id" required data-placeholder="Cari nama pegawai..."
                            class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                            <option value="" disabled {{ $sel('pic_id') ? '' : 'selected' }}>— Pilih —</option>
                            @foreach ($pegawaiList as $p)
                                <option value="{{ $p->id }}" @selected($sel('pic_id') == $p->id)>
                                    {{ $p->nama_gelar ?? $p->nama }}
                                </option>
                            @endforeach
                        </select>
                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                            fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                </div>

                <div class="h-px bg-gray-50"></div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">PPK <span
                                class="text-red-400">*</span></label>
                        <div class="relative">
                            <select name="ppk_id" required data-placeholder="Cari PPK..."
                                class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                                <option value="" disabled {{ $sel('ppk_id') ? '' : 'selected' }}>— Pilih —</option>
                                @forelse ($ppkList as $p)
                                    <option value="{{ $p->id }}" data-nama="{{ $p->nama }}" data-nip="{{ $p->nip }}"
                                        @selected($sel('ppk_id') == $p->id)>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel PPK</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">Bendahara <span
                                class="text-red-400">*</span></label>
                        <div class="relative">
                            <select name="bendahara_id" required data-placeholder="Cari Bendahara..."
                                class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                                <option value="" disabled {{ $sel('bendahara_id') ? '' : 'selected' }}>— Pilih —
                                </option>
                                @forelse ($bendaharaList as $p)
                                    <option value="{{ $p->id }}" data-nama="{{ $p->nama }}" data-nip="{{ $p->nip }}"
                                        @selected($sel('bendahara_id') == $p->id)>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel Bendahara</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">Penanggung Jawab Kegiatan <span
                                class="text-red-400">*</span></label>
                        <div class="relative">
                            <select name="penanggung_jawab_id" required data-placeholder="Cari Penanggung Jawab..."
                                class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                                <option value="" disabled {{ $sel('penanggung_jawab_id') ? '' : 'selected' }}>—
                                    Pilih —
                                </option>
                                @forelse ($pjList as $p)
                                    <option value="{{ $p->id }}" data-nama="{{ $p->nama }}" data-nip="{{ $p->nip }}"
                                        @selected($sel('penanggung_jawab_id') == $p->id)>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel ini</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">Petugas Verifikasi <span
                                class="text-red-400">*</span></label>
                        <div class="relative">
                            <select name="petugas_verifikasi_id" required data-placeholder="Cari Petugas Verifikasi..."
                                class="js-searchable w-full appearance-none bg-white border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition">
                                <option value="" disabled {{ $sel('petugas_verifikasi_id') ? '' : 'selected' }}>—
                                    Pilih
                                    —
                                </option>
                                @forelse ($petugasVerifikasiList as $p)
                                    <option value="{{ $p->id }}" data-nama="{{ $p->nama }}" data-nip="{{ $p->nip }}"
                                        @selected($sel('petugas_verifikasi_id') == $p->id)>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel Petugas Verifikasi</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- ===== Section: Anggaran ===== --}}
        <div
            class="bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow  p-5 sm:p-6">
            <div class="flex items-center gap-2.5 mb-6">
                <div class="h-8 w-8 rounded-lg bg-emerald-50 flex items-center justify-center flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-emerald-600" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V6m0 10v2m9-8a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <div>
                    <h3 class="text-sm font-semibold text-gray-800">Anggaran</h3>
                    <p class="text-xs text-gray-400">MAK dan nominal yang diajukan</p>
                </div>
            </div>

            <div class="space-y-5">
                <!-- MAK -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">MAK
                        <span class="text-red-400">*</span></label>

                    @if ($makOptions->isNotEmpty())
                        {{-- Select asli disembunyikan (TANPA js-searchable). Tetap jadi sumber nilai
                        supaya skrip sinkron MAK / preview uraian / kartu sisa tetap jalan. --}}
                        <select id="mak-select" class="hidden" tabindex="-1" aria-hidden="true">
                            <option value="" data-label="" {{ !$currentMak ? 'selected' : '' }}>— Pilih dari daftar MAK
                                —
                            </option>
                            @foreach ($makGroups as $payung => $items)
                                @foreach ($items as $opt)
                                    <option value="{{ $opt->mak }}"
                                        data-label="{{ \Illuminate\Support\Str::afterLast($opt->mak, '.') }} — {{ $opt->uraian_belanja }}"
                                        data-uraian-giat="{{ $opt->uraian_giat }}"
                                        data-uraian-komponen="{{ $opt->uraian_komponen }}"
                                        data-uraian-akun-ap="{{ $opt->uraian_akun_ap }}"
                                        data-uraian-belanja="{{ $opt->uraian_belanja }}" data-pagu="{{ (int) $opt->pagu }}"
                                        data-realisasi="{{ (int) $opt->realisasi }}" data-sisa="{{ (int) $opt->sisa }}"
                                        data-outstanding-sendiri="{{ (int) ($makOutstanding[$opt->mak]['sendiri'] ?? 0) }}"
                                        data-outstanding-lain="{{ (int) ($makOutstanding[$opt->mak]['lain'] ?? 0) }}"
                                        data-periode="{{ $opt->periode }}"
                                        data-per-tanggal="{{ $opt->per_tanggal ? \Carbon\Carbon::parse($opt->per_tanggal)->format('d/m/Y') : '' }}"
                                        @selected($currentMak === $opt->mak)>
                                        {{ $opt->mak }}
                                    </option>
                                @endforeach
                            @endforeach
                            <option value="__manual__" data-label="Ketik manual (belum ada di daftar)"
                                @selected($tampilkanManual && $currentMak)>
                                Ketik manual (belum ada di daftar)
                            </option>
                        </select>

                        {{-- Dropdown MAK buatan sendiri: header ringkas per payung + item yang dijorok --}}
                        <div id="mak-combo" class="relative mb-2">
                            <input type="text" id="mak-search" autocomplete="off" placeholder="Cari MAK..."
                                value="{{ $currentLabel }}"
                                class="w-full border border-gray-200 rounded-xl pl-3.5 pr-10 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition bg-white placeholder:text-gray-400">
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>

                            <div id="mak-panel"
                                class="hidden absolute z-30 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg max-h-96 overflow-y-auto">
                                @foreach ($makGroups as $payung => $items)
                                    @php $first = $items->first(); @endphp
                                    <div class="mak-group">
                                        {{-- Header ringkas per payung --}}
                                        <div class="sticky top-0 z-10 px-3.5 py-1.5 bg-gray-50 border-y border-gray-100">
                                            <div class="flex items-center gap-2">
                                                <span
                                                    class="font-mono text-[11px] font-semibold text-indigo-700 bg-white border border-gray-200 rounded px-1.5 py-0.5">{{ $payung }}</span>
                                                <span class="text-[11px] text-gray-400">{{ $items->count() }} akun
                                                    belanja</span>
                                            </div>
                                            <div class="text-xs font-semibold text-gray-700 mt-1 truncate"
                                                title="{{ $first->uraian_giat }}">{{ $first->uraian_giat }}</div>
                                            <div class="text-[11px] text-gray-500 truncate"
                                                title="{{ $first->uraian_komponen }}">
                                                {{ $first->uraian_komponen }}
                                            </div>
                                        </div>

                                        {{-- Item dijorok + garis vertikal tipis supaya kelihatan anak dari header --}}
                                        <div class="ml-4 my-1 border-l border-gray-200">
                                            @foreach ($items as $opt)
                                                @php
                                                    $efektif = $makSisaEfektif[$opt->mak] ?? (int) $opt->sisa;
                                                    // Edit: nominal memo ini sudah masuk realisasi FA, kembalikan ke sisa
                                                    if ($memoSudahDiFa && $opt->mak === $memo->mak) {
                                                        $efektif += (int) round((float) $memo->nominal);
                                                    }
                                                    $tidakCukup = $efektif <= 0;
                                                @endphp
                                                <button type="button" data-mak="{{ $opt->mak }}"
                                                    data-search="{{ mb_strtolower($opt->mak . ' ' . $opt->uraian_belanja . ' ' . $opt->uraian_giat . ' ' . $opt->uraian_komponen) }}"
                                                    class="mak-item w-full text-left flex items-center gap-3 -ml-px pl-4 pr-3.5 py-2 border-l-2 border-transparent hover:bg-blue-50 transition">
                                                    <span class="flex-1 min-w-0">
                                                        <span
                                                            class="block font-mono text-[11px] text-gray-400">{{ \Illuminate\Support\Str::beforeLast($opt->mak, '.') }}.<span
                                                                class="font-bold text-gray-800">{{ \Illuminate\Support\Str::afterLast($opt->mak, '.') }}</span></span>
                                                        <span class="block text-sm text-gray-800">{{ $opt->uraian_belanja }}</span>
                                                    </span>
                                                    <span class="text-right flex-shrink-0">
                                                        <span class="block text-[10px] uppercase tracking-wide text-gray-400">Sisa
                                                            tersedia</span>
                                                        <span
                                                            class="block text-sm font-semibold tabular-nums {{ $tidakCukup ? 'text-red-600' : 'text-emerald-600' }}">
                                                            Rp {{ number_format($efektif, 0, ',', '.') }}
                                                        </span>
                                                    </span>
                                                    @if ($tidakCukup)
                                                        <span
                                                            class="flex-shrink-0 rounded-full border border-red-100 bg-red-50 px-2 py-0.5 text-[11px] font-medium text-red-600">Tidak
                                                            cukup</span>
                                                    @endif
                                                    <svg xmlns="http://www.w3.org/2000/svg"
                                                        class="mak-check hidden h-4 w-4 text-blue-600 flex-shrink-0" fill="none"
                                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                                    </svg>
                                                </button>
                                            @endforeach
                                        </div>
                                    </div>
                                @endforeach

                                <p id="mak-empty" class="hidden px-3.5 py-3 text-xs text-gray-400">MAK tidak
                                    ditemukan.</p>

                                <button type="button" data-mak="__manual__" data-search="ketik manual"
                                    class="mak-item w-full text-left px-3.5 py-2 text-xs text-blue-600 font-semibold border-t border-gray-100 hover:bg-blue-50 transition">
                                    + Ketik manual (belum ada di daftar)
                                </button>
                            </div>
                        </div>
                    @else
                        <p class="text-xs text-amber-600 bg-amber-50 border border-amber-100 rounded-xl px-3 py-2 mb-2">
                            Belum ada master MAK — isi manual di bawah.
                        </p>
                    @endif

                    <input type="text" id="mak-input" name="mak" value="{{ $currentMak }}" required
                        placeholder="7458.ABR.006.075.EE.524119"
                        class="w-full border border-gray-200 rounded-xl px-3.5 py-2.5 text-sm font-mono focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition placeholder:text-gray-300 {{ $tampilkanManual ? '' : 'hidden' }}">
                    <p class="text-xs text-gray-400 mt-1.5">
                        Format: KodeGiat.KodeKomponen.KodeAkun.KodeBelanja dipisah titik jadi 6 bagian. Kode di
                        bawah ini otomatis terisi dari MAK.
                    </p>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                        <div class="bg-gray-50/60 rounded-lg p-2.5">
                            <label class="block text-[11px] font-medium text-gray-400 mb-1">Kode Giat</label>
                            <input type="text" id="preview-kode-giat" readonly tabindex="-1"
                                class="w-full border border-gray-200 rounded-lg px-2.5 py-2 text-xs bg-white text-gray-600">
                            <p id="preview-uraian-giat" class="text-[11px] text-gray-400 mt-1 leading-snug"></p>
                        </div>
                        <div class="bg-gray-50/60 rounded-lg p-2.5">
                            <label class="block text-[11px] font-medium text-gray-400 mb-1">Kode Komponen</label>
                            <input type="text" id="preview-kode-komponen" readonly tabindex="-1"
                                class="w-full border border-gray-200 rounded-lg px-2.5 py-2 text-xs bg-white text-gray-600">
                            <p id="preview-uraian-komponen" class="text-[11px] text-gray-400 mt-1 leading-snug"></p>
                        </div>
                        <div class="bg-gray-50/60 rounded-lg p-2.5">
                            <label class="block text-[11px] font-medium text-gray-400 mb-1">Kode Akun (AP)</label>
                            <input type="text" id="preview-kode-akun-ap" readonly tabindex="-1"
                                class="w-full border border-gray-200 rounded-lg px-2.5 py-2 text-xs bg-white text-gray-600">
                            <p id="preview-uraian-akun-ap" class="text-[11px] text-gray-400 mt-1 leading-snug"></p>
                        </div>
                        <div class="bg-gray-50/60 rounded-lg p-2.5">
                            <label class="block text-[11px] font-medium text-gray-400 mb-1">Kode Belanja</label>
                            <input type="text" id="preview-kode-belanja" readonly tabindex="-1"
                                class="w-full border border-gray-200 rounded-lg px-2.5 py-2 text-xs bg-white text-gray-600">
                            <p id="preview-uraian-belanja" class="text-[11px] text-gray-400 mt-1 leading-snug"></p>
                        </div>
                    </div>

                    {{-- Khusus edit: nominal memo ini sendiri sudah tercatat di realisasi FA --}}
                    @if ($memoSudahDiFa)
                        <span id="sisa-mak-koreksi" class="hidden" data-mak="{{ $memo->mak }}"
                            data-nominal="{{ (int) round((float) $memo->nominal) }}"></span>
                    @endif

                    @include('memo._sisa-mak')

                    @error('mak')
                        <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Nominal -->
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5 tracking-wide uppercase">Nominal
                        <span class="text-red-400">*</span></label>
                    <div class="relative">
                        <span
                            class="absolute left-3.5 top-1/2 -translate-y-1/2 text-sm text-gray-400 pointer-events-none">Rp</span>
                        <input type="text" inputmode="numeric" name="nominal" value="{{ $nominalAwal }}" required
                            placeholder="0" id="nominal-input"
                            class="w-full border border-gray-200 rounded-xl pl-9 pr-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-2 focus:ring-blue-100 outline-none transition placeholder:text-gray-300">
                    </div>
                    @error('nominal')
                        <p class="text-xs text-red-500 mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        {{-- Actions --}}
        <div
            class="flex flex-col-reverse sm:flex-row items-center justify-between gap-3 bg-white rounded-2xl border border-gray-100 shadow-sm px-5 sm:px-7 py-4">
            <a href="{{ route('memo.index') }}"
                class="w-full sm:w-auto text-center text-sm text-gray-400 hover:text-gray-600 transition">
                &larr; Batal
            </a>
            <button type="submit"
                class="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 bg-blue-600 hover:bg-blue-700 active:scale-[0.98] text-white font-semibold px-5 py-2.5 rounded-xl text-sm shadow-md shadow-blue-600/20 transition-all">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                {{ $isEdit ? 'Simpan Perubahan' : 'Simpan Nomor Memo' }}
            </button>
        </div>
    </form>

    @include('memo._preview')
</div>

<style>
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-4px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes spin {
        to {
            transform: rotate(360deg);
        }
    }

    .spinning {
        animation: spin 0.8s linear infinite;
    }

    /* Matiin panah bawaan browser di semua <select>, biar cuma panah custom (svg) yang tampil */
    select {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        background-image: none !important;
    }

    select::-ms-expand {
        display: none;
    }
</style>

<script>
    @unless ($isEdit)
        // Tombol "Ambil Nomor Memo" (hanya di halaman create)
        (function () {
            const btn = document.getElementById('btn-ambil-memo');
            const input = document.getElementById('nomor-memo-input');
            const icon = document.getElementById('icon-ambil-memo');
            const label = document.getElementById('label-ambil-memo');
            if (!btn || !input) return;

            btn.addEventListener('click', async function () {
                const teksAsli = label.textContent;
                btn.disabled = true;
                label.textContent = 'Mengambil...';
                icon.classList.add('spinning');
                try {
                    const res = await fetch('{{ route('memo.nomor-berikutnya') }}');
                    const data = await res.json();
                    input.value = data.nomor;
                    input.dispatchEvent(new Event('input', { bubbles: true }));   // <-- tambahan
                    input.classList.add('ring-2', 'ring-green-200', 'border-green-300');
                    setTimeout(() => input.classList.remove('ring-2', 'ring-green-200', 'border-green-300'), 900);
                } catch (e) {
                    alert('Gagal mengambil nomor memo. Coba lagi.');
                } finally {
                    btn.disabled = false;
                    label.textContent = teksAsli;
                    icon.classList.remove('spinning');
                }
            });
        })();
    @endunless

    (function () {
        const makInput = document.getElementById('mak-input');
        if (!makInput) return;

        const previewGiat = document.getElementById('preview-kode-giat');
        const previewKomponen = document.getElementById('preview-kode-komponen');
        const previewAkun = document.getElementById('preview-kode-akun-ap');
        const previewBelanja = document.getElementById('preview-kode-belanja');

        function splitMak() {
            const parts = makInput.value.split('.');
            if (parts.length === 6) {
                previewGiat.value = parts.slice(0, 3).join('.');
                previewKomponen.value = parts[3];
                previewAkun.value = parts[4];
                previewBelanja.value = parts[5];
            } else {
                previewGiat.value = '';
                previewKomponen.value = '';
                previewAkun.value = '';
                previewBelanja.value = '';
            }
        }

        makInput.addEventListener('input', splitMak);
        splitMak();
    })();

    (function () {
        const makSelect = document.getElementById('mak-select');
        const makInput = document.getElementById('mak-input');
        if (!makSelect || !makInput) return;

        const uraianGiat = document.getElementById('preview-uraian-giat');
        const uraianKomponen = document.getElementById('preview-uraian-komponen');
        const uraianAkunAp = document.getElementById('preview-uraian-akun-ap');
        const uraianBelanja = document.getElementById('preview-uraian-belanja');

        function isiUraian(opt) {
            uraianGiat.textContent = opt?.dataset.uraianGiat || '';
            uraianKomponen.textContent = opt?.dataset.uraianKomponen || '';
            uraianAkunAp.textContent = opt?.dataset.uraianAkunAp || '';
            uraianBelanja.textContent = opt?.dataset.uraianBelanja || '';
        }

        makSelect.addEventListener('change', function () {
            if (makSelect.value === '__manual__') {
                makInput.classList.remove('hidden');
                makInput.value = '';
                makInput.focus();
                makInput.dispatchEvent(new Event('input'));
                isiUraian(null);
                return;
            }

            makInput.classList.add('hidden');
            makInput.value = makSelect.value;
            makInput.dispatchEvent(new Event('input'));
            isiUraian(makSelect.selectedOptions[0]);
        });

        isiUraian(makSelect.selectedOptions[0]);
    })();

    // Dropdown MAK buatan sendiri (header per payung + daftar kode belanja).
    // Cuma UI: pilihan diteruskan ke <select id="mak-select"> yang disembunyikan,
    // lalu event "change"-nya ditangani skrip sinkron di atas.
    (function () {
        const combo = document.getElementById('mak-combo');
        const select = document.getElementById('mak-select');
        if (!combo || !select) return;

        const search = document.getElementById('mak-search');
        const panel = document.getElementById('mak-panel');
        const empty = document.getElementById('mak-empty');
        const items = Array.from(panel.querySelectorAll('.mak-item'));
        const groups = Array.from(panel.querySelectorAll('.mak-group'));

        function labelTerpilih() {
            const opt = select.selectedOptions[0];
            return opt ? (opt.dataset.label || '') : '';
        }

        // Tandai item terpilih: latar biru muda, teks tebal, garis biru di kiri, dan centang di kanan.
        // Tombol "Ketik manual" tidak punya .mak-check, jadi cuma kena latar + tebal.
        function tandaiTerpilih() {
            items.forEach(function (el) {
                const aktif = el.dataset.mak === select.value && select.value !== '';
                const cek = el.querySelector('.mak-check');

                el.classList.toggle('bg-blue-50', aktif);
                el.classList.toggle('font-semibold', aktif);

                if (cek) {
                    cek.classList.toggle('hidden', !aktif);
                    el.classList.toggle('border-blue-500', aktif);
                    el.classList.toggle('border-transparent', !aktif);
                }
            });
        }

        function filter(q) {
            q = q.trim().toLowerCase();
            let adaHasil = false;

            groups.forEach(function (g) {
                let adaDiGrup = false;
                g.querySelectorAll('.mak-item').forEach(function (el) {
                    const cocok = !q || el.dataset.search.includes(q);
                    el.classList.toggle('hidden', !cocok);
                    if (cocok) adaDiGrup = true;
                });
                g.classList.toggle('hidden', !adaDiGrup);
                if (adaDiGrup) adaHasil = true;
            });

            empty.classList.toggle('hidden', adaHasil);
        }

        function buka() {
            filter('');
            tandaiTerpilih();
            panel.classList.remove('hidden');
        }

        function tutup() {
            panel.classList.add('hidden');
            search.value = labelTerpilih(); // kembalikan teks kalau user batal milih
        }

        search.addEventListener('focus', function () {
            search.select();
            buka();
        });
        search.addEventListener('click', function () {
            if (panel.classList.contains('hidden')) buka();
        });
        search.addEventListener('input', function () {
            panel.classList.remove('hidden');
            filter(search.value);
        });
        search.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                tutup();
                search.blur();
            }
        });

        items.forEach(function (el) {
            // mousedown supaya kepilih sebelum input kehilangan fokus
            el.addEventListener('mousedown', function (e) {
                e.preventDefault();
                select.value = el.dataset.mak;
                select.dispatchEvent(new Event('change', { bubbles: true }));
                panel.classList.add('hidden');
                search.value = labelTerpilih();
                search.blur();
            });
        });

        document.addEventListener('mousedown', function (e) {
            if (!combo.contains(e.target) && !panel.classList.contains('hidden')) tutup();
        });
    })();

    (function () {
        const nominalInput = document.getElementById('nominal-input');
        if (!nominalInput) return;

        function formatRibuan(angka) {
            const bersih = angka.replace(/\D/g, '');
            return bersih.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }

        // format nilai awal (misal hasil dari old() atau data memo yang diedit)
        if (nominalInput.value) {
            nominalInput.value = formatRibuan(nominalInput.value);
        }

        nominalInput.addEventListener('input', function () {
            const posDariBelakang = this.value.length - this.selectionStart;
            this.value = formatRibuan(this.value);
            const posBaru = this.value.length - posDariBelakang;
            this.setSelectionRange(posBaru, posBaru);
        });

        // sebelum submit, buang titik pemisah biar backend tetap terima angka murni
        const form = nominalInput.closest('form');
        if (form) {
            form.addEventListener('submit', function () {
                nominalInput.value = nominalInput.value.replace(/\./g, '');
            });
        }
    })();

    // Select PIC / PPK / Bendahara / dst. (class js-searchable) di-enhance oleh
    // resources/js/searchable.js (global). JANGAN dipasang lagi di sini, kalau tidak
    // dobel dan select asli yang `required` taersembunyi -> form tidak bisa submit.

    // Preview teks "Hal" di PDF dari tipe pembayaran + jenis memo
    (function () {
        const tipeEl = document.getElementById('tipe-pembayaran');
        const jenisEl = document.getElementById('jenis-memo');
        const out = document.getElementById('preview-hal');
        if (!tipeEl || !jenisEl || !out) return;

        const TIPE = @json(\App\Models\MemoEntry::TIPE_PEMBAYARAN);
        const JENIS = @json(\App\Models\MemoEntry::JENIS_HAL);

        function render() {
            // Nilai ketikan manual (tidak ada di daftar) dipakai apa adanya, sama seperti di PDF.
            const tipe = TIPE[tipeEl.value] || tipeEl.value || '';
            const jenis = JENIS[jenisEl.value] || jenisEl.value || '';
            out.textContent = (tipe + ' ' + jenis).trim();
        }

        tipeEl.addEventListener('change', render);
        jenisEl.addEventListener('change', render);
        render();
    })();
</script>