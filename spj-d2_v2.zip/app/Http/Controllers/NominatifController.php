<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\MemoUntukNominatif;
use App\Models\Agenda;
use App\Models\KabupatenKota;
use App\Models\NominatifEntry;
use App\Models\Pegawai;
use App\Services\MemoTahapService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class NominatifController extends Controller
{
    use MemoUntukNominatif;

    public function index()
    {
        $rows = collect();

        $agendas = Agenda::with(['pegawai', 'pic'])->latest()->get();

        foreach ($agendas as $agenda) {
            $komponen = $agenda->komponen_biaya ?? [];
            $picAgenda = $agenda->pic?->nama_gelar ?? $agenda->pic?->nama;

            foreach (['pns' => 'PNS', 'non-pns' => 'Non PNS'] as $slug => $label) {
                $peserta = $agenda->pegawai->where('status_kepegawaian', $label);

                if ($peserta->isEmpty()) {
                    continue;
                }

                $total = $peserta->sum(function ($p) use ($komponen) {
                    return collect($komponen)->sum(fn($key) => (float) ($p->pivot->{$key} ?? 0));
                });

                $tujuan = collect([$agenda->kota_tujuan ?? null, $agenda->tujuan ?? null])->filter()->implode(', ');

                $rows->push([
                    'id' => 'agenda-' . $agenda->id . '-' . $slug,
                    'group_key' => 'agenda-' . $agenda->id,
                    'sumber' => 'agenda',
                    'uraian_kegiatan' => $agenda->uraian_kegiatan,
                    'tujuan' => $tujuan ?: '-',
                    'tanggal' => $this->labelTanggal($agenda->tanggal_mulai, $agenda->tanggal_selesai),
                    'pic' => $picAgenda,
                    'sort' => optional($agenda->tanggal_mulai)->timestamp ?? 0,
                    'status' => $label,
                    'jumlah_peserta' => $peserta->count(),
                    'total' => $total,
                    'pdf_url' => route('agendas.nominatif', ['agenda' => $agenda->id, 'status' => $slug]),
                    'edit_url' => null,
                    'delete_url' => null,
                ]);
            }
        }

        $entries = NominatifEntry::with(['peserta', 'items', 'pic', 'memo'])->get();

        $tahapMemo = MemoTahapService::petaTahap(
            $entries->filter(fn($e) => $e->memo)
                ->mapWithKeys(fn($e) => ['entry-' . $e->memo->id => $e->memo->status_anggaran ?? 'outstanding'])
                ->all()
        );

        foreach ($entries as $entry) {
            $custom = $entry->jenis_detail === 'custom';
            $tujuan = collect([$entry->kota ?? null, $entry->provinsi ?? null])->filter()->implode(', ');

            $terkunci = $entry->memo
                && !(($entry->memo->status_anggaran ?? 'outstanding') === 'outstanding'
                    && in_array($tahapMemo['entry-' . $entry->memo->id] ?? null, ['draft', 'dikembalikan'], true));

            $rows->push([
                'id' => 'entry-' . $entry->id,
                'group_key' => 'entry-' . $entry->id,
                'sumber' => 'mandiri',
                'uraian_kegiatan' => $entry->uraian_kegiatan,
                'tujuan' => $tujuan ?: '-',
                'tanggal' => $this->labelTanggal($entry->tanggal, null),
                'pic' => $entry->pic?->nama_gelar ?? $entry->pic?->nama,
                'sort' => optional($entry->tanggal)->timestamp ?? 0,
                'status' => $custom ? 'Custom' : 'Honorarium',
                'jumlah_peserta' => $custom ? $entry->items->count() : $entry->peserta->count(),
                'total' => $custom ? $entry->totalAkhir() : $entry->totalBruto(),
                'pdf_url' => $custom ? route('nominatif.custom.pdf', $entry->id) : route('nominatif.pdf', $entry->id),
                'edit_url' => $terkunci ? null : ($custom ? route('nominatif.custom.edit', $entry->id) : route('nominatif.edit', $entry->id)),
                'delete_url' => $terkunci ? null : route('nominatif.destroy', $entry->id),
                'memo_nomor' => $entry->memo?->nomor_memo,
                'terkunci' => (bool) $terkunci,
            ]);
        }

        $rows = $rows->sortByDesc('sort')->values();

        // Satu grup = satu agenda (atau satu honorarium mandiri).
        // groupBy mempertahankan urutan kemunculan pertama, jadi urutan tanggal tetap.
        $groups = $rows
            ->groupBy('group_key')
            ->map(function ($items) {
                $first = $items->first();

                return [
                    'uraian_kegiatan' => $first['uraian_kegiatan'],
                    'tujuan' => $first['tujuan'],
                    'tanggal' => $first['tanggal'],
                    'memo_nomor' => $first['memo_nomor'] ?? null,
                    'pic' => $items->pluck('pic')->filter()->first() ?: '-',
                    // PNS di atas, Non PNS di bawah
                    'items' => $items
                        ->sortBy(fn($i) => $i['status'] === 'PNS' ? 0 : 1)
                        ->values()
                        ->all(),
                ];
            })
            ->values();

        return view('nominatif.index', compact('groups'));
    }

    public function create(Request $request)
    {
        $memo = $this->memoUntukNominatif($request->query('memo'));

        $kabKotaMap = KabupatenKota::orderBy('nama')->get()->groupBy('provinsi')->map(fn($group) => $group->pluck('nama')->values());

        return view('nominatif.create', [
            'nominatif' => null,
            'pegawaiList' => Pegawai::orderBy('nama')->get(),
            'kabKotaMap' => $kabKotaMap,
            'memo' => $memo,
            'prefill' => $this->prefillDariMemo($memo),
        ]);
    }

    public function store(Request $request)
    {
        $data = $this->validasi($request);
        $memo = $this->memoUntukNominatif($data['memo_entry_id'] ?? null);

        $atribut = Arr::except($data, ['peserta', 'memo_entry_id']);
        if ($memo) {
            // unit_id disalin eksplisit: admin tidak diisi otomatis oleh BelongsToUnit.
            $atribut['memo_entry_id'] = $memo->id;
            $atribut['unit_id'] = $memo->unit_id;
            $atribut['penanggung_jawab_id'] = $memo->penanggung_jawab_id;
        }

        DB::transaction(function () use ($atribut, $data) {
            $entry = NominatifEntry::create($atribut);
            $this->simpanPeserta($entry, $data['peserta']);
        });

        return redirect()->route($memo ? 'memo.index' : 'nominatif.index')
            ->with('success', 'Nominatif berhasil dibuat.');
    }

    public function edit(NominatifEntry $nominatif)
    {
        abort_if($nominatif->terkunci(), 403, 'Nominatif terkunci karena memo sudah dikirim ke Keuangan.');
        $nominatif->load('peserta');

        $kabKotaMap = KabupatenKota::orderBy('nama')->get()->groupBy('provinsi')->map(fn($group) => $group->pluck('nama')->values());

        return view('nominatif.edit', [
            'nominatif' => $nominatif,
            'pegawaiList' => Pegawai::orderBy('nama')->get(),
            'kabKotaMap' => $kabKotaMap,
        ]);
    }

    public function update(Request $request, NominatifEntry $nominatif)
    {
        abort_if($nominatif->terkunci(), 403, 'Nominatif terkunci karena memo sudah dikirim ke Keuangan.');

        $data = $this->validasi($request);

        DB::transaction(function () use ($data, $nominatif) {
            $nominatif->update(Arr::except($data, ['peserta', 'memo_entry_id']));
            $this->simpanPeserta($nominatif, $data['peserta']);
        });

        return redirect()->route('nominatif.index')
            ->with('success', 'Nominatif berhasil diperbarui.');
    }

    public function destroy(NominatifEntry $nominatif)
    {
        abort_if($nominatif->terkunci(), 403, 'Nominatif terkunci karena memo sudah dikirim ke Keuangan.');

        $nominatif->delete(); // baris narasumber ikut terhapus (cascade)

        return redirect()->route('nominatif.index')
            ->with('success', 'Nominatif berhasil dihapus.');
    }

    /**
     * PDF 2 halaman (landscape):
     * 1. Daftar Honorarium Narasumber + tanda tangan Bendahara dan PPK
     * 2. Daftar Hadir Narasumber
     */
    public function pdf(NominatifEntry $nominatif)
    {
        $nominatif->load(['peserta', 'ppk', 'bendahara', 'pic']);

        $pdf = Pdf::loadView('pdf.honorarium-narasumber', [
            'entry' => $nominatif,
            'peserta' => $nominatif->peserta,
            'ppk' => $nominatif->ppk,
            'bendahara' => $nominatif->bendahara,
        ])->setPaper('a4', 'landscape');

        return $pdf->stream('Honorarium-Narasumber-' . $nominatif->id . '.pdf');
    }

    private function validasi(Request $request): array
    {
        return $request->validate([
            'uraian_kegiatan' => 'required|string',
            'tanggal' => 'required|date',
            'ppk_id' => 'required|exists:pegawai,id',
            'provinsi' => ['required', 'string', 'max:100'],
            'kota' => ['required', 'string', 'max:100'],
            'bendahara_id' => 'required|exists:pegawai,id',
            'pic_id' => 'required|exists:pegawai,id',
            'memo_entry_id' => 'nullable|integer',
            'peserta' => 'required|array|min:1',
            'peserta.*.nama' => 'required|string|max:255',
            'peserta.*.npwp' => 'nullable|string|max:50',
            'peserta.*.sebagai' => 'nullable|string|max:100',
            'peserta.*.instansi' => 'nullable|string|max:255',
            'peserta.*.golongan' => 'nullable|string|max:50',
            'peserta.*.jabatan' => 'required|string|max:255',
            'peserta.*.honor' => 'required|string',
            'peserta.*.oj' => 'required|integer|min:1',
            'peserta.*.pajak_persen' => 'nullable|numeric|min:0|max:100',
        ], [
            'peserta.required' => 'Tambahkan minimal satu narasumber.',
            'peserta.*.nama.required' => 'Nama narasumber wajib diisi.',
            'peserta.*.jabatan.required' => 'Jabatan narasumber wajib diisi.',
            'peserta.*.honor.required' => 'Honor narasumber wajib diisi.',
            'peserta.*.oj.required' => 'Jumlah OJ wajib diisi.',
            'peserta.*.oj.min' => 'Jumlah OJ minimal 1.',
            'pic_id.required' => 'PIC wajib dipilih.',
        ]);
    }

    private function simpanPeserta(NominatifEntry $entry, array $peserta): void
    {
        $entry->peserta()->delete();

        foreach (array_values($peserta) as $i => $row) {
            $entry->peserta()->create([
                'urutan' => $i,
                'nama' => $row['nama'],
                'npwp' => $row['npwp'] ?? null,
                'sebagai' => ($row['sebagai'] ?? '') !== '' ? $row['sebagai'] : 'Narasumber',
                'instansi' => $row['instansi'] ?? null,
                'golongan' => $row['golongan'] ?? null,
                'jabatan' => $row['jabatan'] ?? null,
                // Honor dikirim dengan titik ribuan ("1.000.000"), ambil angkanya saja
                'honor' => (int) preg_replace('/\D/', '', (string) $row['honor']),
                'oj' => (int) $row['oj'],
                'pajak_persen' => (float) ($row['pajak_persen'] ?? 0),
            ]);
        }
    }

    private function labelTanggal($mulai, $selesai): string
    {
        if (!$mulai) {
            return '-';
        }

        $awal = $mulai->translatedFormat('d M Y');

        if (!$selesai || $mulai->isSameDay($selesai)) {
            return $awal;
        }

        return $awal . ' – ' . $selesai->translatedFormat('d M Y');
    }

    public function pilih(Request $request)
    {
        $memo = $this->memoUntukNominatif($request->query('memo'));

        abort_if($memo === null, 404);

        return view('nominatif.pilih', ['memo' => $memo]);
    }
}