<x-app-layout title="Peserta">
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight break-words">
            Rincian Biaya
        </h2>
    </x-slot>

    {{-- Responsif: tabel input biaya lebarnya banyak, jadi di bawah 1024px tabel bisa
    digeser ke samping dan kolom Nama dikunci (sticky) di kiri.
    Di desktop (>=1024px) tampilan tetap seperti semula. --}}
    <style>
        .peserta-scroll th[data-col="tanggal"],
        .peserta-scroll td[data-col="tanggal"] {
            min-width: 14rem;
        }

        .tgl-card input[type="date"] {
            width: 100%;
            min-width: 0;
            background: #f9fafb;
            border: 1px solid transparent;
            border-radius: 0.375rem;
            padding: 0.3rem 0.375rem;
            font-size: 11px;
            color: #374151;
            transition: background-color .15s, border-color .15s, box-shadow .15s;
        }

        .tgl-card input[type="date"]:hover {
            border-color: #e5e7eb;
        }

        .tgl-card input[type="date"]:focus {
            outline: none;
            background: #fff;
            border-color: #93c5fd;
            box-shadow: 0 0 0 2px rgba(147, 197, 253, .35);
        }

        .tgl-card input[type="date"]::-webkit-calendar-picker-indicator {
            opacity: .45;
            cursor: pointer;
        }

        .tgl-card input[type="date"]::-webkit-calendar-picker-indicator:hover {
            opacity: 1;
        }

        @media (max-width: 1023px) {
            .peserta-scroll table {
                width: max-content;
                min-width: 100%;
            }

            .peserta-scroll th[data-col],
            .peserta-scroll td[data-col] {
                min-width: 7.5rem;
            }

            .peserta-scroll th[data-col="lumpsum"],
            .peserta-scroll td[data-col="lumpsum"] {
                min-width: 11rem;
            }

            .peserta-scroll th[data-col="tanggal"],
            .peserta-scroll td[data-col="tanggal"] {
                min-width: 14rem;
            }

            .peserta-scroll thead th:first-child,
            .peserta-scroll tbody td:first-child:not(.cell-empty),
            .peserta-scroll tfoot td:first-child {
                position: sticky;
                left: 0;
                z-index: 1;
                width: 6.5rem;
                min-width: 6.5rem;
                max-width: 6.5rem;
                box-shadow: 1px 0 0 #e5e7eb;
            }

            .peserta-scroll thead th:first-child,
            .peserta-scroll tfoot td:first-child {
                background: #f9fafb;
            }

            .peserta-scroll tbody td:first-child:not(.cell-empty) {
                background: #fff;
            }

            /* nama boleh turun baris di HP, tidak dipotong "..." */
            .peserta-scroll tbody td:first-child span {
                white-space: normal;
                word-break: break-word;
                font-size: 11px;
                line-height: 1.3;
            }
        }
    </style>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">

            @include('agendas.partials.stepper', ['step' => 2, 'agenda' => $agenda])

            @php
                // ================== Semua komponen biaya & jenis UH yang mungkin ada ==================
                // Pemilihan komponen dilakukan di halaman ini (chip di atas tabel).
                // SEMUA kolom di-render sekali di HTML, lalu JS yang munculkan/sembunyikan
                // sesuai chip yang dicentang — supaya nominal yang sudah diisi tidak hilang.
                $komponenOptions = [
                    'tiket' => 'Tiket',
                    'dukungan_transportasi' => 'Dukungan Transportasi',
                    'transportasi_darat' => 'Transportasi Darat',
                    'transportasi_lokal' => 'Transportasi Lokal',
                    'peng_riil' => 'Peng. Riil',
                    'hotel' => 'Hotel',
                    'penginapan_30' => 'Penginapan 30%',
                    'lumpsum' => 'Uang Harian (Lumpsum)',
                    'representatif' => 'Representatif',
                ];

                $uhFieldMap = [
                    'uh_biasa' => ['hari' => 'hari_dinas_biasa', 'rate' => 'rate_dinas_biasa', 'label' => 'Biasa'],
                    'uh_biasa_60' => ['hari' => 'hari_biasa_60', 'rate' => 'rate_biasa_60', 'label' => 'Biasa 60%'],
                    'uh_fullday' => ['hari' => 'hari_fullday', 'rate' => 'rate_fullday', 'label' => 'Fullday'],
                    'uh_fullboard' => ['hari' => 'hari_fullboard', 'rate' => 'rate_fullboard', 'label' => 'FullBoard'],
                ];

                // Kolom "simple" = semua komponen selain lumpsum, satu input per kolom.
                $simpleKomponen = collect($komponenOptions)->except('lumpsum')->all();

                $selectedKomponen = old('komponen_biaya', $agenda->komponen_biaya ?? []);
                $selectedUh = old('jenis_uang_harian', $agenda->jenis_uang_harian ?? []);

                // Lookup cepat id -> nama tujuan buat label di popup Peng. Riil
                $pengRiilRateNameById = $pengRiilRates->flatten()->pluck('tujuan', 'id');

                // Rate UH dipatok dari SBM sesuai provinsi tujuan agenda.
                $uhRates = [
                    'uh_biasa' => (int) ($sbmRate->uh_biasa ?? 0),
                    'uh_biasa_60' => (int) ($sbmRate->uh_biasa_60 ?? 0),
                    'uh_fullday' => (int) ($sbmFlat->uh_fullday ?? 0),
                    'uh_fullboard' => (int) ($sbmFlat->uh_fullboard ?? 0),
                ];

                // helper: ambil nilai bersih sebagai integer
                $cleanNum = function ($v) {
                    if ($v === null || $v === '') {
                        return null;
                    }
                    $intPart = explode('.', (string) $v)[0];
                    $digits = preg_replace('/\D/', '', $intPart);
                    return $digits === '' ? null : (int) $digits;
                };

                // Rentang surat tugas (batas & default tanggal peserta)
                $agendaMulai = $agenda->tanggal_mulai->format('Y-m-d');
                $agendaSelesai = $agenda->tanggal_selesai->format('Y-m-d');

                // Urutan sama kayak halaman Pegawai
                $pegawaiList = $pegawaiList->sort(function ($a, $b) {
                    $urutanA = $a->urutan ?? PHP_INT_MAX;
                    $urutanB = $b->urutan ?? PHP_INT_MAX;

                    return $urutanA <=> $urutanB
                        ?: $b->golongan_rank <=> $a->golongan_rank
                        ?: $a->nama <=> $b->nama;
                })->values();

                $pnsList = $pegawaiList->filter(fn($p) => ($p->status_kepegawaian ?? 'PNS') === 'PNS')->values();
                $nonPnsList = $pegawaiList->filter(fn($p) => ($p->status_kepegawaian ?? 'PNS') === 'Non PNS')->values();
            @endphp

            @if ($errors->any())
                <div class="bg-red-50 border border-red-200 rounded-xl px-4 sm:px-5 py-3 text-xs text-red-700">
                    <ul class="list-disc pl-4 space-y-0.5">
                        @foreach (collect($errors->all())->unique() as $err)
                            <li>{{ $err }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if (!$sbmRate && in_array('lumpsum', $selectedKomponen))
                <div class="bg-amber-50 border border-amber-200 rounded-xl px-4 sm:px-5 py-3 text-xs text-amber-800 mb-4">
                    Rate SBM untuk provinsi "<strong>{{ $agenda->tujuan }}</strong>" belum ada di master data.
                    Uang Harian sementara bernilai Rp 0 sampai datanya dilengkapi.
                </div>
            @endif
            @if ($pengRiilRates->isEmpty() && in_array('peng_riil', $selectedKomponen))
                <div class="bg-amber-50 border border-amber-200 rounded-xl px-4 sm:px-5 py-3 text-xs text-amber-800 mb-4">
                    Master rate Peng. Riil (transportasi) belum di-seed. Opsi "SBM" di popup Peng. Riil belum ada
                    pilihannya — isi manual (at cost) dulu.
                </div>
            @endif

            <form action="{{ route('agendas.peserta.store', $agenda) }}" method="POST" id="peserta-form">
                @csrf

                {{-- Komponen biaya untuk agenda ini — kolom di tabel bawah menyesuaikan
                secara langsung (tanpa reload) sesuai chip yang dicentang di sini --}}
                <div class="mb-6">
                    @include('agendas.partials.komponen-biaya-selector', ['agenda' => $agenda])
                </div>

                {{-- Info rentang surat tugas --}}
                <div class="bg-blue-50 border border-blue-100 rounded-xl px-4 sm:px-5 py-3 text-xs text-blue-800">
                    Rentang surat tugas:
                    <strong>{{ $agenda->tanggal_mulai->translatedFormat('d M Y') }}
                        – {{ $agenda->tanggal_selesai->translatedFormat('d M Y') }}</strong>.
                    Tanggal tiap peserta boleh lebih pendek dari rentang ini; kalau tidak diubah, peserta ikut rentang
                    penuh.
                </div>

                @foreach ([
                        ['key' => 'pns', 'label' => 'Pegawai PNS', 'list' => $pnsList, 'accent' => 'blue'],
                        ['key' => 'nonpns', 'label' => 'Pegawai Non PNS', 'list' => $nonPnsList, 'accent' => 'amber'],
                    ] as $group)
                    <div class="bg-white shadow-sm rounded-xl border border-gray-100 overflow-hidden mb-6 mt-6">
                        {{-- Header grup --}}
                        <div
                            class="px-4 sm:px-5 py-4 border-b border-gray-100 flex flex-wrap items-center justify-between gap-3 bg-{{ $group['accent'] }}-50/60">
                            <div class="flex items-center gap-2.5">
                                <span
                                    class="flex items-center justify-center h-7 w-7 rounded-full bg-{{ $group['accent'] }}-100 text-{{ $group['accent'] }}-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                                        stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round"
                                            d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                    </svg>
                                </span>
                                <div>
                                    <h3 class="font-semibold text-gray-800 leading-tight">{{ $group['label'] }}</h3>
                                    <span class="text-xs text-gray-400">{{ $group['list']->count() }} orang</span>
                                </div>
                            </div>
                            {{-- Petunjuk geser: hanya di HP/tablet --}}
                            <span class="lg:hidden text-[11px] text-gray-400">Geser tabel ke samping →</span>
                        </div>

                        {{-- Pembungkus scroll horizontal (HP/tablet). Di desktop tidak ada efek. --}}
                        <div class="peserta-scroll overflow-x-auto">
                            <table class="w-full table-auto text-sm">
                                <thead>
                                    <tr class="bg-gray-50 text-[11px] uppercase tracking-wide text-gray-500">
                                        <th class="px-3 py-2.5 text-left font-medium">Nama</th>
                                        <th class="px-2 py-2.5 text-center font-medium" data-col="tanggal">Tanggal Dinas
                                        </th>
                                        @foreach ($simpleKomponen as $key => $label)
                                            <th class="px-2 py-2.5 text-center font-medium {{ in_array($key, $selectedKomponen) ? '' : 'hidden' }}"
                                                data-col="{{ $key }}">
                                                {{ $label }}
                                                @if ($key === 'peng_riil')
                                                    <div class="text-[9px] font-normal normal-case text-gray-400">SBM / Manual</div>
                                                @endif
                                            </th>
                                        @endforeach
                                        <th class="px-2 py-2.5 text-center font-medium {{ in_array('lumpsum', $selectedKomponen) ? '' : 'hidden' }}"
                                            data-col="lumpsum">Uang Harian (Lumpsum)</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-100">
                                    @forelse ($group['list'] as $p)
                                        @php
                                            $pivot = $p->pivot;
                                            $nama = $p->nama_gelar ?? $p->nama;
                                            $lumpsumAwal = 0;
                                            foreach ($uhFieldMap as $f) {
                                                $lumpsumAwal += ($pivot->{$f['hari']} ?? 0) * ($pivot->{$f['rate']} ?? 0);
                                            }

                                            // Tanggal efektif peserta: kolom pivot kalau diisi, kalau tidak ikut agenda
                                            $tglMulaiPeserta = old(
                                                'tanggal_mulai.' . $p->id,
                                                ($pivot->tanggal_mulai ?? null)
                                                ? \Carbon\Carbon::parse($pivot->tanggal_mulai)->format('Y-m-d')
                                                : $agendaMulai
                                            );
                                            $tglSelesaiPeserta = old(
                                                'tanggal_selesai.' . $p->id,
                                                ($pivot->tanggal_selesai ?? null)
                                                ? \Carbon\Carbon::parse($pivot->tanggal_selesai)->format('Y-m-d')
                                                : $agendaSelesai
                                            );
                                        @endphp
                                        <tr class="peserta-row hover:bg-gray-50/60 transition" data-group="{{ $group['key'] }}">
                                            <td class="px-3 py-2 overflow-hidden">
                                                <span class="font-medium text-gray-800 text-sm truncate block"
                                                    title="{{ $nama }}">{{ $nama }}</span>
                                            </td>

                                            {{-- Tanggal dinas per peserta --}}
                                            <td class="px-2 py-2" data-col="tanggal">
                                                <div
                                                    class="tgl-card rounded-xl border border-gray-200 bg-white p-2 space-y-2 shadow-sm">
                                                    <div class="grid grid-cols-[1fr_auto_1fr] items-end gap-1.5">
                                                        <label class="block min-w-0">
                                                            <span
                                                                class="block text-[9px] uppercase tracking-wide text-gray-400 mb-0.5">Mulai</span>
                                                            <input type="date" name="tanggal_mulai[{{ $p->id }}]"
                                                                class="tgl-mulai" aria-label="Tanggal mulai dinas {{ $nama }}"
                                                                min="{{ $agendaMulai }}" max="{{ $agendaSelesai }}"
                                                                value="{{ $tglMulaiPeserta }}">
                                                        </label>
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            class="h-3.5 w-3.5 mb-2 text-gray-300 flex-shrink-0" fill="none"
                                                            viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M5 12h14M13 6l6 6-6 6" />
                                                        </svg>
                                                        <label class="block min-w-0">
                                                            <span
                                                                class="block text-[9px] uppercase tracking-wide text-gray-400 mb-0.5">Selesai</span>
                                                            <input type="date" name="tanggal_selesai[{{ $p->id }}]"
                                                                class="tgl-selesai"
                                                                aria-label="Tanggal selesai dinas {{ $nama }}"
                                                                min="{{ $tglMulaiPeserta }}" max="{{ $agendaSelesai }}"
                                                                value="{{ $tglSelesaiPeserta }}">
                                                        </label>
                                                    </div>

                                                    <div class="flex items-center justify-between gap-2">
                                                        <span
                                                            class="inline-flex items-center gap-1 rounded-full bg-{{ $group['accent'] }}-100 text-{{ $group['accent'] }}-600 px-2 py-0.5 text-[10px] font-semibold">
                                                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none"
                                                                viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                                                <path stroke-linecap="round" stroke-linejoin="round"
                                                                    d="M8 7V3m8 4V3M5 11h14M5 5h14a1 1 0 011 1v13a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1z" />
                                                            </svg>
                                                            <span class="row-lama">-</span> hari
                                                        </span>
                                                        <button type="button"
                                                            class="tgl-reset hidden text-[10px] text-gray-400 hover:text-{{ $group['accent'] }}-600 underline underline-offset-2">Semua
                                                            hari</button>
                                                    </div>

                                                    <div
                                                        class="row-warn hidden rounded-md bg-amber-50 border border-amber-200 px-2 py-1 text-[10px] text-amber-700 text-center">
                                                        Total hari UH ≠ lama dinas
                                                    </div>
                                                </div>
                                            </td>

                                            @foreach ($simpleKomponen as $key => $label)
                                                @if ($key === 'peng_riil')
                                                    @php
                                                        // ==== Peng. Riil mendukung multi-entry ====
                                                        // Disimpan sebagai JSON array di kolom pivot `peng_riil_detail`,
                                                        // tiap entry: {mode, value, rate_id, tujuan, keterangan}.
                                                        $pengRiilDetailRaw = $pivot->peng_riil_detail ?? null;
                                                        $pengRiilEntries = [];
                                                        if ($pengRiilDetailRaw) {
                                                            $decoded = is_string($pengRiilDetailRaw)
                                                                ? json_decode($pengRiilDetailRaw, true)
                                                                : $pengRiilDetailRaw;
                                                            if (is_array($decoded)) {
                                                                $pengRiilEntries = $decoded;
                                                            }
                                                        }
                                                        // Fallback: migrasikan data lama (single mode/value) jadi 1 entry
                                                        if (empty($pengRiilEntries) && ($pivot->peng_riil ?? 0) > 0) {
                                                            $oldMode = $pivot->peng_riil_mode ?? 'manual';
                                                            $oldRateId = $pivot->peng_riil_rate_id ?? '';
                                                            $pengRiilEntries = [
                                                                [
                                                                    'mode' => $oldMode,
                                                                    'value' => (int) ($pivot->peng_riil ?? 0),
                                                                    'rate_id' => $oldRateId,
                                                                    'tujuan' => $pengRiilRateNameById[$oldRateId] ?? '',
                                                                    'keterangan' => '',
                                                                ]
                                                            ];
                                                        }
                                                        $pengRiilTotal = collect($pengRiilEntries)->sum(fn($e) => (int) ($e['value'] ?? 0));
                                                        $pengRiilCount = count($pengRiilEntries);
                                                    @endphp
                                                    <td class="px-2 py-2 {{ in_array('peng_riil', $selectedKomponen) ? '' : 'hidden' }}"
                                                        data-col="peng_riil">
                                                        <button type="button"
                                                            class="peng-riil-open-btn w-full border border-dashed border-gray-300 rounded-md px-2 py-1.5 text-[11px] text-gray-600 hover:border-{{ $group['accent'] }}-400 hover:text-{{ $group['accent'] }}-600 transition text-center"
                                                            data-pegawai-id="{{ $p->id }}" data-nama="{{ $nama }}"
                                                            data-detail='{{ json_encode($pengRiilEntries, JSON_UNESCAPED_UNICODE) }}'>
                                                            <span class="peng-riil-display font-semibold text-gray-700 block">
                                                                {{ $pengRiilTotal ? 'Rp ' . number_format($pengRiilTotal) : 'Isi Peng. Riil' }}
                                                            </span>
                                                            <span class="peng-riil-sub block text-[9px] text-gray-400">
                                                                @if ($pengRiilCount > 1)
                                                                    {{ $pengRiilCount }} item
                                                                @elseif ($pengRiilCount === 1)
                                                                    {{ $pengRiilEntries[0]['mode'] === 'sbm' ? 'SBM' : 'Manual' }}
                                                                @endif
                                                            </span>
                                                        </button>

                                                        <input type="hidden" class="col-peng_riil" name="peng_riil[{{ $p->id }}]"
                                                            data-group="{{ $group['key'] }}" value="{{ $pengRiilTotal }}">
                                                        <input type="hidden" class="peng-riil-detail-field"
                                                            name="peng_riil_detail[{{ $p->id }}]"
                                                            value='{{ json_encode($pengRiilEntries, JSON_UNESCAPED_UNICODE) }}'>
                                                    </td>
                                                @else
                                                    <td class="px-2 py-2 {{ in_array($key, $selectedKomponen) ? '' : 'hidden' }}"
                                                        data-col="{{ $key }}">
                                                        <input type="text" inputmode="numeric" name="{{ $key }}[{{ $p->id }}]"
                                                            placeholder="0"
                                                            class="rupiah-input col-{{ $key }} w-full border border-gray-200 rounded-md px-2 py-1.5 text-center text-xs focus:border-{{ $group['accent'] }}-400 focus:ring-1 focus:ring-{{ $group['accent'] }}-400 outline-none transition"
                                                            data-group="{{ $group['key'] }}"
                                                            value="{{ $cleanNum($pivot->{$key} ?? null) }}">
                                                    </td>
                                                @endif
                                            @endforeach

                                            <td class="px-2 py-2 {{ in_array('lumpsum', $selectedKomponen) ? '' : 'hidden' }}"
                                                data-col="lumpsum">
                                                <div class="space-y-1">
                                                    <div class="flex items-center justify-between gap-1 text-[9px]">
                                                        <span class="uh-mode-label text-gray-400">Otomatis dari tanggal</span>
                                                        <button type="button"
                                                            class="uh-auto-btn hidden text-{{ $group['accent'] }}-600 hover:underline">↺
                                                            Otomatis</button>
                                                    </div>
                                                    @foreach ($uhFieldMap as $uhKey => $f)
                                                        <div class="{{ in_array($uhKey, $selectedUh) ? '' : 'hidden' }}"
                                                            data-uh="{{ $uhKey }}">
                                                            <div class="text-[9px] text-gray-400 leading-tight">{{ $f['label'] }}
                                                            </div>
                                                            <div class="flex items-center gap-1">
                                                                <input type="text" inputmode="numeric"
                                                                    name="{{ $f['hari'] }}[{{ $p->id }}]" placeholder="hr"
                                                                    class="hari-input col-{{ $f['hari'] }} w-9 flex-shrink-0 border border-gray-200 rounded-md px-1 py-1.5 text-center text-[11px] focus:border-{{ $group['accent'] }}-400 focus:ring-1 focus:ring-{{ $group['accent'] }}-400 outline-none transition"
                                                                    data-group="{{ $group['key'] }}"
                                                                    value="{{ $pivot->{$f['hari']} ?? '' }}">
                                                                <span class="text-[10px] text-gray-300 flex-shrink-0">x</span>
                                                                <input type="text" inputmode="numeric" readonly
                                                                    name="{{ $f['rate'] }}[{{ $p->id }}]" placeholder="0"
                                                                    class="rupiah-input col-{{ $f['rate'] }} w-full border border-gray-200 bg-gray-50 rounded-md px-1.5 py-1.5 text-center text-[11px] text-gray-500 cursor-not-allowed outline-none"
                                                                    data-group="{{ $group['key'] }}"
                                                                    title="Dipatok dari SBM sesuai tujuan agenda"
                                                                    value="{{ $uhRates[$uhKey] }}">
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                    <div
                                                        class="text-[10px] text-gray-500 text-center pt-0.5 border-t border-gray-100">
                                                        Total: <span class="row-lumpsum-total font-semibold">Rp
                                                            {{ number_format($lumpsumAwal) }}</span>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    @empty
                                        <tr>
                                            <td colspan="100%" class="cell-empty px-4 py-6 text-center text-gray-400">
                                                Belum ada peserta di kategori ini. Kembali ke halaman "Buat Agenda" untuk
                                                menambahkan.
                                            </td>
                                        </tr>
                                    @endforelse
                                </tbody>
                                @if ($group['list']->isNotEmpty())
                                    <tfoot>
                                        <tr class="bg-gray-50 border-t border-gray-200 font-semibold text-gray-700 text-xs">
                                            <td class="px-3 py-2.5">Subtotal</td>
                                            <td data-col="tanggal"></td>
                                            @foreach ($simpleKomponen as $key => $label)
                                                <td class="px-2 py-2.5 text-center total-{{ $key }} {{ in_array($key, $selectedKomponen) ? '' : 'hidden' }}"
                                                    data-group="{{ $group['key'] }}" data-col="{{ $key }}">Rp 0</td>
                                            @endforeach
                                            <td class="px-2 py-2.5 text-center total-lumpsum {{ in_array('lumpsum', $selectedKomponen) ? '' : 'hidden' }}"
                                                data-group="{{ $group['key'] }}" data-col="lumpsum">Rp 0</td>
                                        </tr>
                                    </tfoot>
                                @endif
                            </table>
                        </div>
                    </div>
                @endforeach

                <div class="sticky bottom-4 flex justify-end">
                    <button type="submit"
                        class="w-full sm:w-auto justify-center inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium px-5 py-2.5 rounded-lg shadow-lg shadow-blue-600/25 transition">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                            stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                        {{ empty($agenda->mak) ? 'Simpan & Lanjut ke Anggaran' : 'Simpan Peserta' }}
                    </button>
                </div>

                {{-- Popup Peng. Riil — satu modal dipakai bareng buat semua baris peserta.
                Mendukung banyak entry sekaligus (tombol "+ Tambah"), tiap entry bisa
                Manual atau Sesuai SBM sendiri-sendiri. --}}
                <div id="peng-riil-modal"
                    class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
                    <div class="bg-white rounded-xl shadow-xl w-full max-w-md p-5 space-y-4 max-h-[90vh] overflow-y-auto"
                        onclick="event.stopPropagation()">
                        <div class="flex items-center justify-between">
                            <h3 class="font-semibold text-gray-800">Isi Peng. Riil</h3>
                            <button type="button" id="peng-riil-modal-close"
                                class="text-gray-400 hover:text-gray-600 text-xl leading-none px-2 -mr-2">&times;</button>
                        </div>
                        <p class="text-xs text-gray-500" id="peng-riil-modal-nama"></p>

                        <div id="peng-riil-modal-entries" class="space-y-3"></div>

                        <button type="button" id="peng-riil-modal-add"
                            class="w-full text-xs font-medium text-blue-600 hover:text-blue-700 border border-dashed border-blue-300 hover:border-blue-400 rounded-lg py-2.5 sm:py-2 transition">
                            + Tambah
                        </button>

                        <div class="text-xs text-gray-600 text-right pt-1 border-t border-gray-100">
                            Total: <span id="peng-riil-modal-total" class="font-semibold text-gray-800">Rp 0</span>
                        </div>

                        <div class="flex justify-end gap-2 pt-2">
                            <button type="button" id="peng-riil-modal-cancel"
                                class="px-4 py-2 text-sm rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 transition">Batal</button>
                            <button type="button" id="peng-riil-modal-save"
                                class="px-4 py-2 text-sm rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition">Simpan</button>
                        </div>
                    </div>

                    {{-- Template satu baris entry Peng. Riil, di-clone tiap klik "+ Tambah" --}}
                    <template id="peng-riil-entry-template">
                        <div class="peng-riil-entry border border-gray-200 rounded-lg p-3 space-y-2.5 relative">
                            <button type="button"
                                class="peng-riil-entry-remove absolute top-1.5 right-1.5 text-gray-300 hover:text-red-500 text-lg sm:text-sm leading-none w-7 h-7 sm:w-5 sm:h-5 flex items-center justify-center">&times;</button>

                            <div class="flex flex-wrap gap-x-4 gap-y-1 text-xs pr-7">
                                <label class="inline-flex items-center gap-1.5 cursor-pointer">
                                    <input type="radio" class="entry-mode-radio" value="manual" checked>
                                    Manual (At Cost)
                                </label>
                                <label class="inline-flex items-center gap-1.5 cursor-pointer">
                                    <input type="radio" class="entry-mode-radio" value="sbm">
                                    Sesuai SBM
                                </label>
                            </div>

                            <div class="entry-manual-section">
                                <label class="block text-[11px] font-semibold text-gray-500 mb-1">Nominal</label>
                                <input type="text" inputmode="numeric" placeholder="0"
                                    class="entry-manual-input w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition">
                            </div>

                            <div class="entry-sbm-section hidden">
                                <label class="block text-[11px] font-semibold text-gray-500 mb-1">Tujuan</label>
                                <select
                                    class="entry-sbm-select w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition">
                                    <option value="">Pilih tujuan</option>
                                    @foreach ($pengRiilRates as $kategori => $rates)
                                        <optgroup
                                            label="{{ $kategori === 'jabodetabek' ? 'Transport Jakarta' : 'Transport Daerah' }}">
                                            @foreach ($rates as $r)
                                                <option value="{{ $r->id }}" data-rate="{{ (int) $r->rate_one_way }}"
                                                    data-kategori="{{ $kategori }}" data-tujuan="{{ $r->tujuan }}">
                                                    {{ $r->tujuan }}
                                                </option>
                                            @endforeach
                                        </optgroup>
                                    @endforeach
                                </select>
                                <p class="text-[11px] text-gray-500 mt-1.5">
                                    Rate PP (2x satu arah): <span
                                        class="entry-sbm-preview font-semibold text-gray-700">Rp 0</span>
                                </p>
                            </div>

                            <div>
                                <label class="block text-[11px] font-semibold text-gray-500 mb-1">Keterangan</label>
                                <input type="text" placeholder="mis. Transport Jakarta – Kab. Bogor PP"
                                    class="entry-keterangan-input w-full border border-gray-200 rounded-lg px-3 py-2 text-xs focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition">
                            </div>
                        </div>
                    </template>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Daftar SEMUA kolom "simple" & pasangan hari/rate lumpsum yang mungkin ada.
        // Totalnya tetap dihitung walau kolomnya disembunyikan.
        const SIMPLE_COLS = @json(array_keys($simpleKomponen));
        const LUMPSUM_FIELDS = @json(array_values(array_map(
            fn($f) => ['hari' => $f['hari'], 'rate' => $f['rate']],
            $uhFieldMap
        )));
        const LUMPSUM_RATE_COLS = new Set(LUMPSUM_FIELDS.map(f => 'col-' + f.rate));

        // ==== Toggle kolom tabel real-time sesuai chip "Komponen Biaya" & "Jenis Uang Harian" ====
        document.querySelectorAll('input[name="komponen_biaya[]"]').forEach(function (cb) {
            function syncKomponenCol() {
                document.querySelectorAll('[data-col="' + cb.value + '"]').forEach(function (el) {
                    el.classList.toggle('hidden', !cb.checked);
                });
            }
            cb.addEventListener('change', syncKomponenCol);
            syncKomponenCol();
        });

        document.querySelectorAll('input[name="jenis_uang_harian[]"]').forEach(function (cb) {
            function syncUhPair() {
                document.querySelectorAll('[data-uh="' + cb.value + '"]').forEach(function (el) {
                    el.classList.toggle('hidden', !cb.checked);
                });
            }
            cb.addEventListener('change', syncUhPair);
            syncUhPair();
        });

        // Ambil digit murni saja dari sebuah string
        function onlyDigits(value) {
            return String(value ?? '').replace(/\D/g, '');
        }

        // Format angka jadi "500.000"
        function formatRupiah(rawValue) {
            const digits = onlyDigits(rawValue);
            if (!digits) return '';
            const trimmed = digits.replace(/^0+(?=\d)/, '');
            return trimmed.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }

        // Hitung total lumpsum satu baris dari semua pasangan hari/rate yang aktif
        function rowLumpsumValue(row) {
            let total = 0;
            LUMPSUM_FIELDS.forEach(function (f) {
                const hariEl = row.querySelector('.col-' + f.hari);
                const blk = hariEl ? hariEl.closest('[data-uh]') : null;
                if (blk && blk.classList.contains('hidden')) return; // jenis UH tidak aktif
                const hari = parseInt(onlyDigits(hariEl?.value) || '0', 10);
                const rate = parseInt(onlyDigits(row.querySelector('.col-' + f.rate)?.value) || '0', 10);
                total += hari * rate;
            });
            return total;
        }

        function updateRowLumpsumDisplay(row) {
            const display = row.querySelector('.row-lumpsum-total');
            if (display) {
                display.textContent = 'Rp ' + (formatRupiah(String(rowLumpsumValue(row))) || '0');
            }
        }

        function recalcTotals(group) {
            SIMPLE_COLS.forEach(function (col) {
                let sum = 0;
                document.querySelectorAll('input.col-' + col + '[data-group="' + group + '"]').forEach(function (input) {
                    sum += parseInt(onlyDigits(input.value) || '0', 10);
                });
                const target = document.querySelector('.total-' + col + '[data-group="' + group + '"]');
                if (target) {
                    target.textContent = sum ? ('Rp ' + formatRupiah(String(sum))) : 'Rp 0';
                }
            });

            let lumpsumSum = 0;
            document.querySelectorAll('tr.peserta-row[data-group="' + group + '"]').forEach(function (row) {
                lumpsumSum += rowLumpsumValue(row);
            });
            const lumpsumTarget = document.querySelector('.total-lumpsum[data-group="' + group + '"]');
            if (lumpsumTarget) {
                lumpsumTarget.textContent = lumpsumSum ? ('Rp ' + formatRupiah(String(lumpsumSum))) : 'Rp 0';
            }
        }

        // ==== Tanggal dinas per peserta -> lama hari -> hari uang harian ====
        // Hari UH terisi otomatis dari tanggal. Begitu user mengetik hari secara manual,
        // baris itu masuk mode "manual" (tidak ditimpa lagi) sampai user klik "↺ Otomatis".
        const AGENDA_MULAI = @json($agendaMulai);
        const AGENDA_SELESAI = @json($agendaSelesai);

        function lamaHari(row) {
            const m = row.querySelector('.tgl-mulai')?.value;
            const s = row.querySelector('.tgl-selesai')?.value;
            if (!m || !s) return 0;
            const d = Math.round((new Date(s) - new Date(m)) / 86400000) + 1;
            return d > 0 ? d : 0;
        }

        function activeUhBlocks(row) {
            return Array.from(row.querySelectorAll('[data-uh]'))
                .filter(el => !el.classList.contains('hidden'));
        }

        function activeUhValues(row) {
            return activeUhBlocks(row).map(function (el) {
                return parseInt(onlyDigits(el.querySelector('.hari-input').value) || '0', 10);
            });
        }

        function updateWarn(row) {
            const lama = lamaHari(row);
            const total = activeUhValues(row).reduce((a, b) => a + b, 0);
            const warn = row.querySelector('.row-warn');
            if (warn) warn.classList.toggle('hidden', !(total > 0 && lama > 0 && total !== lama));
        }

        function setMode(row, manual) {
            row.dataset.manual = manual ? '1' : '';
            const label = row.querySelector('.uh-mode-label');
            const btn = row.querySelector('.uh-auto-btn');
            if (label) label.textContent = manual ? 'Diisi manual' : 'Otomatis dari tanggal';
            if (btn) btn.classList.toggle('hidden', !manual);
        }

        // Jenis UH aktif pertama diisi penuh sesuai lama dinas, yang lain dikosongkan
        function applyAutoDays(row) {
            const lama = lamaHari(row);
            const active = activeUhBlocks(row);
            row.querySelectorAll('[data-uh]').forEach(function (block) {
                const input = block.querySelector('.hari-input');
                input.value = (active.indexOf(block) === 0 && lama) ? String(lama) : '';
            });
        }

        // Data yang sudah tersimpan: kalau cocok dengan hasil otomatis -> mode otomatis,
        // kalau beda (diatur manual sebelumnya) -> mode manual supaya tidak tertimpa.
        function detectInitialMode(row) {
            const lama = lamaHari(row);
            const vals = activeUhValues(row);
            const total = vals.reduce((a, b) => a + b, 0);
            const auto = total === 0 || (vals[0] === lama && vals.slice(1).every(v => v === 0));
            setMode(row, !auto);
        }

        function syncRowDays(row) {
            const lama = lamaHari(row);
            const lamaEl = row.querySelector('.row-lama');
            if (lamaEl) lamaEl.textContent = lama || '-';

            const mulai = row.querySelector('.tgl-mulai');
            const selesai = row.querySelector('.tgl-selesai');
            const resetBtn = row.querySelector('.tgl-reset');
            if (resetBtn && mulai && selesai) {
                const beda = mulai.value !== AGENDA_MULAI || selesai.value !== AGENDA_SELESAI;
                resetBtn.classList.toggle('hidden', !beda);
            }

            if (row.dataset.manual !== '1') applyAutoDays(row);

            updateWarn(row);
            updateRowLumpsumDisplay(row);
            recalcTotals(row.dataset.group);
        }

        document.querySelectorAll('tr.peserta-row').forEach(function (row) {
            const mulai = row.querySelector('.tgl-mulai');
            const selesai = row.querySelector('.tgl-selesai');
            if (!mulai || !selesai) return;

            function onDateChange(source) {
                if (mulai.value && selesai.value && mulai.value > selesai.value) {
                    if (source === 'selesai') mulai.value = selesai.value;
                    else selesai.value = mulai.value;
                }
                if (mulai.value) selesai.min = mulai.value;
                syncRowDays(row);
            }

            ['change', 'input'].forEach(function (ev) {
                mulai.addEventListener(ev, function () { onDateChange('mulai'); });
                selesai.addEventListener(ev, function () { onDateChange('selesai'); });
            });

            // "Semua hari" -> kembali ke rentang penuh surat tugas
            const resetBtn = row.querySelector('.tgl-reset');
            if (resetBtn) {
                resetBtn.addEventListener('click', function () {
                    mulai.value = AGENDA_MULAI;
                    selesai.value = AGENDA_SELESAI;
                    selesai.min = AGENDA_MULAI;
                    syncRowDays(row);
                });
            }

            // "↺ Otomatis" -> buang isian manual, hari UH ikut tanggal lagi
            const autoBtn = row.querySelector('.uh-auto-btn');
            if (autoBtn) {
                autoBtn.addEventListener('click', function () {
                    setMode(row, false);
                    syncRowDays(row);
                });
            }
        });

        // Kalau chip "Jenis Uang Harian" diubah, hitung ulang semua baris
        // (listener ini didaftarkan SETELAH listener toggle di atas, jadi class hidden sudah terbarui)
        document.querySelectorAll('input[name="jenis_uang_harian[]"]').forEach(function (cb) {
            cb.addEventListener('change', function () {
                document.querySelectorAll('tr.peserta-row').forEach(function (row) { syncRowDays(row); });
            });
        });

        // ==== Popup Peng. Riil: satu modal dipakai bareng buat semua baris peserta ====
        (function () {
            const modal = document.getElementById('peng-riil-modal');
            if (!modal) return;

            const entriesContainer = document.getElementById('peng-riil-modal-entries');
            const template = document.getElementById('peng-riil-entry-template');
            const addBtn = document.getElementById('peng-riil-modal-add');
            const totalDisplay = document.getElementById('peng-riil-modal-total');
            const namaLabel = document.getElementById('peng-riil-modal-nama');
            let activeBtn = null;
            let entryCounter = 0;

            function entryValue(entryEl) {
                const isSbm = entryEl.querySelector('.entry-mode-radio[value="sbm"]').checked;
                if (isSbm) {
                    const opt = entryEl.querySelector('.entry-sbm-select').selectedOptions[0];
                    return opt && opt.value ? parseInt(opt.dataset.rate || '0', 10) * 2 : 0;
                }
                return parseInt(onlyDigits(entryEl.querySelector('.entry-manual-input').value) || '0', 10);
            }

            function updateModalTotal() {
                let total = 0;
                entriesContainer.querySelectorAll('.peng-riil-entry').forEach(function (el) {
                    total += entryValue(el);
                });
                totalDisplay.textContent = 'Rp ' + (formatRupiah(String(total)) || '0');
            }

            function syncEntryMode(entryEl) {
                const isSbm = entryEl.querySelector('.entry-mode-radio[value="sbm"]').checked;
                entryEl.querySelector('.entry-manual-section').classList.toggle('hidden', isSbm);
                entryEl.querySelector('.entry-sbm-section').classList.toggle('hidden', !isSbm);
            }

            // Keterangan otomatis: "Transport Jakarta – (tujuan) PP" untuk Jabodetabek,
            // atau "Transport Daerah (tujuan) PP" untuk provinsi.
            function updateEntryKeterangan(entryEl) {
                const select = entryEl.querySelector('.entry-sbm-select');
                const preview = entryEl.querySelector('.entry-sbm-preview');
                const keteranganInput = entryEl.querySelector('.entry-keterangan-input');
                const opt = select.selectedOptions[0];

                if (!opt || !opt.value) {
                    preview.textContent = 'Rp 0';
                    return;
                }

                const rate = parseInt(opt.dataset.rate || '0', 10) * 2;
                preview.textContent = 'Rp ' + (formatRupiah(String(rate)) || '0');

                const tujuan = opt.dataset.tujuan || opt.textContent.trim();
                keteranganInput.value = opt.dataset.kategori === 'jabodetabek'
                    ? 'Transport Jakarta – ' + tujuan + ' PP'
                    : 'Transport Daerah (' + tujuan + ') PP';
            }

            function wireEntry(entryEl) {
                entryCounter++;
                // radio per-entry perlu name unik biar tidak "berbagi" pilihan antar entry
                const radioName = 'peng-riil-entry-mode-' + entryCounter;
                entryEl.querySelectorAll('.entry-mode-radio').forEach(function (r) { r.name = radioName; });

                entryEl.querySelectorAll('.entry-mode-radio').forEach(function (r) {
                    r.addEventListener('change', function () {
                        syncEntryMode(entryEl);
                        updateModalTotal();
                    });
                });

                const manualInput = entryEl.querySelector('.entry-manual-input');
                manualInput.addEventListener('input', function () {
                    manualInput.value = onlyDigits(manualInput.value);
                    updateModalTotal();
                });
                manualInput.addEventListener('blur', function () {
                    manualInput.value = formatRupiah(manualInput.value);
                });

                const sbmSelect = entryEl.querySelector('.entry-sbm-select');
                sbmSelect.addEventListener('change', function () {
                    updateEntryKeterangan(entryEl);
                    updateModalTotal();
                });

                entryEl.querySelector('.peng-riil-entry-remove').addEventListener('click', function () {
                    if (entriesContainer.querySelectorAll('.peng-riil-entry').length <= 1) {
                        // selalu sisakan minimal 1 baris — reset jadi kosong
                        entryEl.remove();
                        addEntry();
                        updateModalTotal();
                        return;
                    }
                    entryEl.remove();
                    updateModalTotal();
                });
            }

            function addEntry(data) {
                const frag = template.content.cloneNode(true);
                const entryEl = frag.querySelector('.peng-riil-entry');
                entriesContainer.appendChild(frag);
                wireEntry(entryEl);

                if (data) {
                    const isSbm = data.mode === 'sbm';
                    entryEl.querySelector('.entry-mode-radio[value="' + (isSbm ? 'sbm' : 'manual') + '"]').checked = true;
                    syncEntryMode(entryEl);

                    if (isSbm) {
                        entryEl.querySelector('.entry-sbm-select').value = data.rate_id || '';
                        updateEntryKeterangan(entryEl);
                    } else {
                        entryEl.querySelector('.entry-manual-input').value = formatRupiah(String(data.value || ''));
                    }
                    if (data.keterangan) {
                        entryEl.querySelector('.entry-keterangan-input').value = data.keterangan;
                    }
                }

                return entryEl;
            }

            function openModal(btn) {
                activeBtn = btn;
                namaLabel.textContent = btn.dataset.nama || '';
                entriesContainer.innerHTML = '';

                let detail = [];
                try {
                    detail = JSON.parse(btn.dataset.detail || '[]');
                } catch (e) {
                    detail = [];
                }

                if (Array.isArray(detail) && detail.length) {
                    detail.forEach(function (d) { addEntry(d); });
                } else {
                    addEntry();
                }

                updateModalTotal();
                modal.classList.remove('hidden');
            }

            function closeModal() {
                modal.classList.add('hidden');
                activeBtn = null;
            }

            addBtn.addEventListener('click', function () {
                addEntry();
                updateModalTotal();
            });

            document.querySelectorAll('.peng-riil-open-btn').forEach(function (btn) {
                btn.addEventListener('click', function () { openModal(btn); });
            });

            document.getElementById('peng-riil-modal-close').addEventListener('click', closeModal);
            document.getElementById('peng-riil-modal-cancel').addEventListener('click', closeModal);
            modal.addEventListener('click', closeModal); // klik area gelap di luar kartu

            document.getElementById('peng-riil-modal-save').addEventListener('click', function () {
                if (!activeBtn) return;

                const entries = [];
                entriesContainer.querySelectorAll('.peng-riil-entry').forEach(function (entryEl) {
                    const isSbm = entryEl.querySelector('.entry-mode-radio[value="sbm"]').checked;
                    const keterangan = entryEl.querySelector('.entry-keterangan-input').value.trim();

                    if (isSbm) {
                        const opt = entryEl.querySelector('.entry-sbm-select').selectedOptions[0];
                        if (!opt || !opt.value) return; // skip entry SBM yang belum pilih tujuan
                        entries.push({
                            mode: 'sbm',
                            value: parseInt(opt.dataset.rate || '0', 10) * 2,
                            rate_id: opt.value,
                            tujuan: opt.dataset.tujuan || opt.textContent.trim(),
                            keterangan: keterangan,
                        });
                    } else {
                        const value = parseInt(onlyDigits(entryEl.querySelector('.entry-manual-input').value) || '0', 10);
                        if (!value && !keterangan) return; // skip entry manual kosong total
                        entries.push({
                            mode: 'manual',
                            value: value,
                            rate_id: '',
                            tujuan: '',
                            keterangan: keterangan,
                        });
                    }
                });

                const pegawaiId = activeBtn.dataset.pegawaiId;
                const valueInput = document.querySelector('input.col-peng_riil[name="peng_riil[' + pegawaiId + ']"]');
                const detailField = document.querySelector('.peng-riil-detail-field[name="peng_riil_detail[' + pegawaiId + ']"]');
                const displayEl = activeBtn.querySelector('.peng-riil-display');
                const subEl = activeBtn.querySelector('.peng-riil-sub');

                const total = entries.reduce(function (sum, e) { return sum + (e.value || 0); }, 0);
                const entriesJson = JSON.stringify(entries);

                activeBtn.dataset.detail = entriesJson;
                valueInput.value = total;
                detailField.value = entriesJson;

                displayEl.textContent = total ? 'Rp ' + formatRupiah(String(total)) : 'Isi Peng. Riil';
                subEl.textContent = entries.length > 1
                    ? entries.length + ' item'
                    : (entries.length === 1 ? (entries[0].mode === 'sbm' ? 'SBM' : 'Manual') : '');

                recalcTotals(valueInput.dataset.group);
                closeModal();
            });
        })();

        document.querySelectorAll('.rupiah-input').forEach(function (input) {
            // saat halaman dimuat: tampilkan dengan format titik
            input.value = formatRupiah(input.value);

            // saat field difokus: tampilkan angka polos, biar gampang diedit
            input.addEventListener('focus', function () {
                input.value = onlyDigits(input.value);
                requestAnimationFrame(function () {
                    input.setSelectionRange(input.value.length, input.value.length);
                });
            });

            // saat mengetik: hanya izinkan digit, tanpa reformat live (hindari bug kursor)
            input.addEventListener('input', function () {
                input.value = onlyDigits(input.value);
                const row = input.closest('tr.peserta-row');
                if (row) {
                    const isLumpsumRate = Array.from(input.classList).some(c => LUMPSUM_RATE_COLS.has(c));
                    if (isLumpsumRate) updateRowLumpsumDisplay(row);
                }
                recalcTotals(input.dataset.group);
            });

            // saat pindah field: format ulang jadi "500.000"
            input.addEventListener('blur', function () {
                input.value = formatRupiah(input.value);
            });
        });

        // Input jumlah hari (semua jenis UH aktif): digit saja, maksimal 2 digit, tanpa format ribuan
        document.querySelectorAll('.hari-input').forEach(function (input) {
            input.value = onlyDigits(input.value);

            input.addEventListener('input', function () {
                input.value = onlyDigits(input.value).slice(0, 2);
                const row = input.closest('tr.peserta-row');
                setMode(row, true);
                updateWarn(row);
                updateRowLumpsumDisplay(row);
                recalcTotals(input.dataset.group);
            });
        });

        // Inisialisasi: deteksi mode tiap baris (otomatis / manual), isi hari UH dari tanggal, hitung total
        document.querySelectorAll('tr.peserta-row').forEach(function (row) {
            detectInitialMode(row);
            syncRowDays(row);
        });
        ['pns', 'nonpns'].forEach(recalcTotals);

        // sebelum submit, pastikan value yang dikirim adalah angka polos
        document.getElementById('peserta-form').addEventListener('submit', function () {
            document.querySelectorAll('.rupiah-input, .hari-input').forEach(function (input) {
                input.value = onlyDigits(input.value);
            });
        });
    </script>
</x-app-layout>