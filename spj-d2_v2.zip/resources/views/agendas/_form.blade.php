{{--
    Partial form Agenda — dipakai bareng oleh create.blade.php & edit.blade.php.

    Cara pakai:
      Create : @include('agendas._form', ['agenda' => null])
      Edit   : @include('agendas._form', ['agenda' => $agenda])

    Variabel yang dibutuhkan dari controller (ikut ter-inherit dari view induk):
      - $pegawaiList, $provinsiList, $kabKotaMap          (create & edit)
      - $selectedPesertaIds, $pesertaHasBiayaIds          (edit saja)

    Semua perbedaan create vs edit dikontrol lewat $isEdit di bawah.
--}}

@php
    // $agenda = null -> mode create, $agenda berisi model -> mode edit
    $isEdit = !empty($agenda) && $agenda->exists;

    // Peserta yang sudah dipilih sebelumnya, buat pre-check checkbox (kalau
    // form ini di-reload setelah validasi gagal, old() menang).
    $selectedIds = $isEdit ? ($selectedPesertaIds ?? collect())->all() : [];
    $oldPesertaIds = old('pegawai_id', $selectedIds);

    // Daftar id peserta yang sudah punya rincian biaya (cuma relevan di edit).
    $biayaIds = $isEdit ? ($pesertaHasBiayaIds ?? collect()) : collect();

    // Replika logika pengurutan dari PegawaiController@index, supaya urutan
    // peserta di sini persis sama dengan halaman Data Pegawai: dikelompokkan
    // per unit kerja (alfabet, unit kosong ditaruh paling bawah), lalu di dalam
    // tiap unit: PNS diurutkan urutan→golongan_rank, Non PNS diurutkan urutan→nama.
    $sortGolongan = function ($a, $b) {
        $urutanA = $a->urutan ?? PHP_INT_MAX;
        $urutanB = $b->urutan ?? PHP_INT_MAX;

        return $urutanA <=> $urutanB ?: $b->golongan_rank <=> $a->golongan_rank;
    };

    $sortNama = function ($a, $b) {
        $urutanA = $a->urutan ?? PHP_INT_MAX;
        $urutanB = $b->urutan ?? PHP_INT_MAX;

        return $urutanA <=> $urutanB ?: $a->nama <=> $b->nama;
    };

    $unitUrutan = $pegawaiList
        ->map(fn($p) => $p->unit_kerja ?: 'Belum Diisi Unit')
        ->unique()
        ->sort(fn($a, $b) => ($a === 'Belum Diisi Unit' ? 'zzz_' . $a : $a) <=> ($b === 'Belum Diisi Unit' ? 'zzz_' . $b : $b))
        ->values();

    $pesertaPnsList = collect();
    $pesertaNonPnsList = collect();

    foreach ($unitUrutan as $unit) {
        $itemsUnit = $pegawaiList->filter(fn($p) => ($p->unit_kerja ?: 'Belum Diisi Unit') === $unit);

        $pesertaPnsList = $pesertaPnsList->concat(
            $itemsUnit->filter(fn($p) => ($p->status_kepegawaian ?? 'PNS') === 'PNS')->sort($sortGolongan)->values()
        );
        $pesertaNonPnsList = $pesertaNonPnsList->concat(
            $itemsUnit->filter(fn($p) => ($p->status_kepegawaian ?? 'PNS') === 'Non PNS')->sort($sortNama)->values()
        );
    }

    $pesertaPnsList = $pesertaPnsList->values();
    $pesertaNonPnsList = $pesertaNonPnsList->values();

    // role_penandatangan itu kolom teks bebas (bisa lebih dari satu role,
    // misal "PPK, Petugas Verifikasi"), jadi dicocokkan pakai substring —
    // aman karena keempat label tidak ada yang beririsan satu sama lain.
    $ppkList = $pegawaiList
        ->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'PPK'))
        ->values();
    $bendaharaList = $pegawaiList
        ->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'Bendahara'))
        ->values();
    $pjList = $pegawaiList
        ->filter(fn($p) => str_contains($p->role_penandatangan ?? '', 'Penanggung Jawab Kegiatan'))
        ->values();

    $unitKerjaList = $pegawaiList
        ->pluck('unit_kerja')
        ->filter()
        ->unique()
        ->sort()
        ->values();

    // Nilai-nilai field: old() menang, fallback ke data agenda (edit) atau kosong (create)
    $vTujuan = old('tujuan', $agenda?->tujuan);
    $vAlatAngkut = old('alat_angkut', $agenda?->alat_angkut);
    $vPpk = old('ppk_id', $agenda?->ppk_id);
    $vBendahara = old('bendahara_id', $agenda?->bendahara_id);
    $vPj = old('penanggung_jawab_id', $agenda?->penanggung_jawab_id);

    // Tipe pembayaran: old() menang, lalu data agenda (edit), default 'ls' (create) — sama seperti form memo.
    // Nilai ketikan manual (tidak ada di daftar TIPE_PEMBAYARAN) tetap ditampilkan sebagai option custom.
    $currentTipe = old('tipe_pembayaran', $agenda?->tipe_pembayaran ?: 'ls');

    // Badge status agenda (cuma tampil di edit)
    $statusStyle = match (strtolower($agenda?->status ?? '')) {
        'draft' => 'bg-gray-100 text-gray-500',
        'diajukan', 'proses', 'pending' => 'bg-amber-50 text-amber-600',
        'disetujui', 'selesai', 'approved' => 'bg-green-50 text-green-600',
        'ditolak', 'rejected' => 'bg-red-50 text-red-600',
        default => 'bg-gray-100 text-gray-500',
    };
@endphp

{{-- ===== Daftar error validasi ===== --}}
@if ($errors->any())
    @php
        // Label field dalam Bahasa Indonesia, biar error jelas nunjuk ke field
        // mana — dipakai bareng sama nama field asli kalau labelnya belum ke-daftar.
        $fieldLabels = [
            'nomor_st' => 'Nomor Surat Tugas',
            'nomor_st_karo' => 'Nomor ST Khusus (Eselon I/II)',
            'uraian_kegiatan' => 'Uraian Kegiatan',
            'tujuan' => 'Tujuan (Provinsi)',
            'kota_tujuan' => 'Kab/Kota',
            'alat_angkut' => 'Alat Angkut',
            'tipe_pembayaran' => 'Tipe Pembayaran',
            'tanggal_mulai' => 'Tanggal Mulai',
            'tanggal_selesai' => 'Tanggal Selesai',
            'ppk_id' => 'Pejabat Pembuat Komitmen (PPK)',
            'bendahara_id' => 'Bendahara',
            'penanggung_jawab_id' => 'Penanggung Jawab Kegiatan',
            'pic_id' => 'PIC',
            'pegawai_id' => 'Peserta',
            'mak' => 'MAK',
            'uraian_giat' => 'Uraian Giat',
            'uraian_komponen' => 'Uraian Komponen',
            'uraian_akun_ap' => 'Uraian Akun (AP)',
            'uraian_belanja' => 'Uraian Belanja',
            'petugas_verifikasi_id' => 'Petugas Verifikasi',
            'klasifikasi' => 'Klasifikasi',
            'nilai_persen' => 'Nilai %',
            'pagu' => 'Pagu',
            'pengajuan_nominal' => 'Pengajuan',
            'nomor_memo_pns' => 'Nomor Memo (PNS)',
            'nomor_memo_non_pns' => 'Nomor Memo (Non PNS)',
        ];
    @endphp
    <div class="flex gap-2.5 bg-red-50 border border-red-200 text-red-700 text-sm px-4 py-3 rounded-lg mb-5">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 flex-shrink-0 mt-0.5" fill="none"
            viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round"
                d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
        </svg>
        <div>
            <p class="font-semibold mb-1">Ada {{ $errors->count() }} field yang perlu dicek:</p>
            <ul class="space-y-0.5 list-disc list-inside">
                @foreach ($errors->getMessages() as $field => $messages)
                    @php
                        // pegawai_id.* / komponen_biaya.* dll -> ambil nama field induknya aja
                        $baseField = explode('.', $field)[0];
                        $label = $fieldLabels[$baseField] ?? $baseField;
                    @endphp
                    <li>
                        <strong>{{ $label }}</strong>
                        — {{ str_contains($messages[0], 'validation.') ? 'wajib diisi / formatnya belum sesuai' : $messages[0] }}
                    </li>
                @endforeach
            </ul>
        </div>
    </div>
@endif

<form action="{{ $isEdit ? route('agendas.update', $agenda) : route('agendas.store') }}" method="POST"
    id="agenda-form">
    @csrf
    @if ($isEdit)
        @method('PUT')
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-5 gap-6 lg:items-stretch">

        {{-- KOLOM KIRI: pilih peserta (sticky, tinggi menyesuaikan kolom kanan) --}}
        <div class="lg:col-span-2 lg:sticky lg:top-6 lg:h-full">
            <div
                class="lg:h-full flex flex-col bg-white shadow-sm rounded-2xl border border-gray-100 p-6 sm:p-7 space-y-4">

                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600" fill="none"
                                viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m6-5.13a4 4 0 11-8 0 4 4 0 018 0zm6 0a4 4 0 11-3-3.87" />
                            </svg>
                        </div>
                        <div>
                            <h3 class="text-lg font-bold text-gray-800">Peserta</h3>
                        </div>
                    </div>
                    <span id="peserta-count"
                        class="text-xs font-semibold text-blue-600 bg-blue-50 rounded-full px-2.5 py-1 flex-shrink-0">0
                        dipilih</span>
                </div>

                {{-- Peringatan khusus edit: peserta yang sudah punya biaya --}}
                @if ($isEdit)
                    <p class="text-xs text-amber-600 bg-amber-50 border border-amber-100 rounded-lg px-3 py-2">
                        Peserta yang udah punya rincian biaya bakal ditanya konfirmasi dulu kalau di-uncek —
                        biar biayanya gak kehapus gak sengaja.
                    </p>
                @endif

                <div class="flex flex-col sm:flex-row gap-2">
                    <div class="relative flex-1 min-w-0">
                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="h-4 w-4 text-gray-300 absolute left-3.5 top-1/2 -translate-y-1/2" fill="none"
                            viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M21 21l-4.35-4.35M17 11a6 6 0 11-12 0 6 6 0 0112 0z" />
                        </svg>
                        <input type="text" id="peserta-search" placeholder="Cari nama..."
                            class="w-full border border-gray-200 rounded-lg pl-10 pr-8 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition placeholder:text-gray-300">
                        <button type="button" id="peserta-search-clear"
                            class="hidden absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-300 hover:text-gray-500 transition"
                            aria-label="Hapus pencarian">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5" fill="none"
                                viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <div class="relative sm:w-40 flex-shrink-0">
                        <select id="peserta-unit-filter"
                            class="w-full appearance-none border border-gray-200 rounded-lg pl-3 pr-7 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition bg-white text-gray-600">
                            <option value="">Semua unit</option>
                            @foreach ($unitKerjaList as $unit)
                                <option value="{{ strtolower($unit) }}">{{ $unit }}</option>
                            @endforeach
                        </select>
                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="h-3.5 w-3.5 text-gray-400 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none"
                            fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                </div>

                {{-- Chip peserta yang sudah dicentang — nempel di sini, gak ketimbun pas list panjang
                di-scroll --}}
                <div id="peserta-selected-chips" class="hidden flex flex-wrap gap-1.5"></div>

                {{-- Tab switcher --}}
                <div class="flex items-center gap-1.5 border-b border-gray-100">
                    <button type="button" data-tab="pns" data-total="{{ $pesertaPnsList->count() }}"
                        class="peserta-tab-btn text-sm font-medium px-3 py-2 border-b-2 border-blue-600 text-blue-600 -mb-px transition flex items-center gap-1.5">
                        PNS
                        <span
                            class="peserta-tab-badge text-[11px] font-semibold rounded-full px-1.5 py-0.5 bg-blue-50 text-blue-500">{{ $pesertaPnsList->count() }}</span>
                    </button>
                    <button type="button" data-tab="nonpns" data-total="{{ $pesertaNonPnsList->count() }}"
                        class="peserta-tab-btn text-sm font-medium px-3 py-2 border-b-2 border-transparent text-gray-400 hover:text-gray-600 -mb-px transition flex items-center gap-1.5">
                        Non PNS
                        <span
                            class="peserta-tab-badge text-[11px] font-semibold rounded-full px-1.5 py-0.5 bg-gray-100 text-gray-400">{{ $pesertaNonPnsList->count() }}</span>
                    </button>
                    <label
                        class="ml-auto flex items-center gap-1.5 text-xs text-gray-400 cursor-pointer select-none self-center">
                        <input type="checkbox"
                            class="peserta-select-all rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        <span class="peserta-select-all-label">Pilih semua</span>
                    </label>
                </div>

                @foreach ([
                        ['key' => 'pns', 'list' => $pesertaPnsList],
                        ['key' => 'nonpns', 'list' => $pesertaNonPnsList],
                    ] as $group)
                    <div data-peserta-panel="{{ $group['key'] }}"
                        class="{{ $loop->first ? '' : 'hidden' }} flex-1 min-h-[220px] overflow-y-auto divide-y divide-gray-50 -mx-1 pr-1">
                        @forelse ($group['list'] as $p)
                            @php
                                $nama = $p->nama_gelar ?? $p->nama;
                                $butuhStKhusus = $p->butuhStKhusus();
                                $hasBiaya = $biayaIds->contains($p->id);
                            @endphp
                            <label
                                class="peserta-item flex items-center gap-2.5 px-1.5 py-2.5 text-sm rounded-md cursor-pointer transition hover:bg-gray-50 has-[:checked]:bg-blue-50/70"
                                data-nama="{{ strtolower($nama) }}"
                                data-unit="{{ strtolower($p->unit_kerja ?? '') }}">
                                <input type="checkbox" name="pegawai_id[]" value="{{ $p->id }}"
                                    class="peserta-checkbox rounded border-gray-300 text-blue-600 focus:ring-blue-500 flex-shrink-0"
                                    data-has-biaya="{{ $hasBiaya ? '1' : '0' }}"
                                    data-st-khusus="{{ $butuhStKhusus ? '1' : '0' }}"
                                    data-nama-pegawai="{{ $nama }}"
                                    {{ in_array($p->id, $oldPesertaIds) ? 'checked' : '' }}>
                                <span class="min-w-0 flex-1">
                                    <span class="block text-gray-700 truncate">{{ $nama }}</span>
                                    @if ($p->unit_kerja ?? false)
                                        <span
                                            class="block text-[11px] text-gray-400 truncate">{{ $p->unit_kerja }}</span>
                                    @endif
                                </span>
                                @if ($hasBiaya)
                                    <span
                                        class="flex-shrink-0 text-[10px] font-medium text-amber-600 bg-amber-50 rounded-full px-1.5 py-0.5">
                                        ada biaya
                                    </span>
                                @endif
                            </label>
                        @empty
                            <p class="px-1 py-3 text-xs text-gray-400">Tidak ada data.</p>
                        @endforelse
                        <div class="peserta-empty-search hidden px-1 py-8 text-center">
                            <p class="text-sm text-gray-400">Tidak ada nama yang cocok.</p>
                            <button type="button"
                                class="peserta-reset-filters mt-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700">
                                Reset pencarian &amp; filter
                            </button>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>

        {{-- KOLOM KANAN: detail agenda --}}
        <div
            class="lg:col-span-3 bg-white shadow-sm rounded-2xl border border-gray-100 p-6 sm:p-7 space-y-6 lg:h-full">

            <div class="flex items-start justify-between gap-4">
                <div class="flex items-center gap-3">
                    <div class="h-10 w-10 rounded-xl bg-blue-50 flex items-center justify-center flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-blue-600" fill="none"
                            viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                        </svg>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold text-gray-800">Informasi Agenda</h3>
                        <p class="text-sm text-gray-400">Detail perjalanan dinas — nomor ST, tujuan, dan
                            anggarannya.</p>
                    </div>
                </div>
                @if ($isEdit && ($agenda->status ?? false))
                    <span
                        class="flex-shrink-0 inline-block px-2.5 py-1 rounded-full text-xs font-semibold {{ $statusStyle }}">
                        {{ ucfirst($agenda->status) }}
                    </span>
                @endif
            </div>

            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1.5">
                    Nomor Surat Tugas <span class="text-red-400">*</span>
                </label>
                <input type="text" name="nomor_st" value="{{ old('nomor_st', $agenda?->nomor_st) }}" required
                    placeholder="800/123/ST/2026"
                    class="w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition placeholder:text-gray-300">
                <p class="text-xs text-gray-300 mt-1">Dipakai bareng buat semua peserta.</p>
            </div>

            {{-- Muncul otomatis kalau ada peserta Eselon I/II yang dicentang di kolom peserta --}}
            <div id="nomor-st-karo-wrap" class="hidden rounded-lg transition-shadow duration-500">
                <label class="block text-xs font-semibold text-gray-500 mb-1.5">
                    Nomor ST Khusus (Eselon I/II) <span class="text-red-400">*</span>
                    <span id="nomor-st-karo-nama" class="text-gray-300 font-normal"></span>
                </label>
                <input type="text" id="nomor-st-karo-input" name="nomor_st_karo"
                    value="{{ old('nomor_st_karo', $agenda?->nomor_st_karo) }}" placeholder="800/124/ST/2026"
                    class="w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition placeholder:text-gray-300">
                <p class="text-xs text-gray-300 mt-1">Khusus peserta Eselon I/II, biasanya beda nomor dari peserta
                    lain.</p>
            </div>

            <div>
                <label class="block text-xs font-semibold text-gray-500 mb-1.5">Uraian Kegiatan <span
                        class="text-red-400">*</span></label>
                <input type="text" name="uraian_kegiatan"
                    value="{{ old('uraian_kegiatan', $agenda?->uraian_kegiatan) }}" required
                    placeholder="Rapat koordinasi program tahunan"
                    class="w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition placeholder:text-gray-300">
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5">Tujuan (Provinsi) <span
                            class="text-red-400">*</span></label>
                    <select name="tujuan" id="tujuan-select" required data-placeholder="Cari provinsi..."
                        class="js-searchable w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition">
                        <option value="" disabled {{ $vTujuan ? '' : 'selected' }}>Pilih provinsi tujuan</option>
                        @foreach ($provinsiList as $provinsi)
                            <option value="{{ $provinsi }}" @selected($vTujuan === $provinsi)>{{ $provinsi }}</option>
                        @endforeach
                        {{-- Khusus edit: jaga-jaga data lama yang tujuan-nya belum tentu ada di master sbm_rates
                        (misal diisi bebas sebelum fitur ini ada) — tetap muncul biar gak keganti diam-diam --}}
                        @if ($isEdit && $agenda->tujuan && !$provinsiList->contains($agenda->tujuan))
                            <option value="{{ $agenda->tujuan }}" selected>{{ $agenda->tujuan }} (belum ada
                                di master SBM)</option>
                        @endif
                    </select>
                    @if ($provinsiList->isEmpty())
                        <p class="text-xs text-amber-600 mt-1">Belum ada data provinsi di master SBM.</p>
                    @endif
                </div>
                <div>
                    {{-- Kab/Kota: wajib di create, opsional di edit (supaya data lama tanpa kota tetap bisa disimpan) --}}
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5">Kab/Kota
                        @unless ($isEdit)
                            <span class="text-red-400">*</span>
                        @endunless
                    </label>
                    <select name="kota_tujuan" id="kota-tujuan-select"
                        class="js-searchable w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition"
                        data-placeholder="Cari kab/kota..."
                        data-lokasi-provinsi="#tujuan-select"
                        data-lokasi-map='@json($kabKotaMap)'
                        data-lokasi-current="{{ old('kota_tujuan', $agenda?->kota_tujuan) }}"
                        data-lokasi-placeholder="Pilih kab/kota">
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5">Tanggal Mulai <span
                            class="text-red-400">*</span></label>
                    <input type="date" name="tanggal_mulai" id="tanggal-mulai"
                        value="{{ old('tanggal_mulai', $agenda?->tanggal_mulai?->format('Y-m-d')) }}" required
                        class="w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5">Tanggal Selesai <span
                            class="text-red-400">*</span></label>
                    <input type="date" name="tanggal_selesai" id="tanggal-selesai"
                        value="{{ old('tanggal_selesai', $agenda?->tanggal_selesai?->format('Y-m-d')) }}" required
                        class="w-full border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition">
                    <p id="durasi-info" class="hidden text-xs text-blue-500 mt-1"></p>
                </div>
            </div>

            {{-- Alat Angkut + Tipe Pembayaran (sebaris di layar sm ke atas) --}}
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5">Alat Angkut <span
                            class="text-red-400">*</span></label>
                    <div class="relative">
                        <select name="alat_angkut" required
                            class="w-full appearance-none bg-none border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition bg-white">
                            <option value="" disabled {{ $vAlatAngkut ? '' : 'selected' }}>— Pilih —</option>
                            <option value="darat" @selected($vAlatAngkut === 'darat')>Angkutan Darat</option>
                            <option value="udara" @selected($vAlatAngkut === 'udara')>Angkutan Udara</option>
                            <option value="laut" @selected($vAlatAngkut === 'laut')>Angkutan Laut</option>
                            <option value="darat_udara" @selected($vAlatAngkut === 'darat_udara')>Angkutan Darat dan Udara</option>
                        </select>
                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                            fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-gray-500 mb-1.5">Tipe Pembayaran <span
                            class="text-red-400">*</span></label>
                    <div class="relative">
                        {{-- Dipilih dari daftar ATAU diketik manual (lihat data-allow-custom di searchable.js).
                        Nilai ketikan dikirim lewat option data-custom; maks. 20 karakter (kolom DB). --}}
                        <select name="tipe_pembayaran" id="tipe-pembayaran" required data-allow-custom="1"
                            data-maxlength="20" data-placeholder="Pilih atau ketik sendiri..."
                            class="js-searchable w-full appearance-none bg-none border border-gray-200 rounded-lg px-3.5 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition bg-white">
                            @foreach (\App\Models\MemoEntry::TIPE_PEMBAYARAN as $value => $label)
                                <option value="{{ $value }}" @selected($currentTipe === $value)>
                                    {{ \Illuminate\Support\Str::of($label)->afterLast('(')->before(')') }} —
                                    {{ \Illuminate\Support\Str::of($label)->after('Permintaan ')->before(' (') }}
                                </option>
                            @endforeach
                            @if ($currentTipe && !array_key_exists($currentTipe, \App\Models\MemoEntry::TIPE_PEMBAYARAN))
                                <option value="{{ $currentTipe }}" data-custom selected>{{ $currentTipe }}</option>
                            @endif
                        </select>
                        <svg xmlns="http://www.w3.org/2000/svg"
                            class="h-4 w-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                            fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                    <p class="text-xs text-gray-300 mt-1">Dipakai nanti buat memo agenda ini.</p>
                </div>
            </div>

            {{-- ===== Penanggung jawab ===== --}}
            <div class="pt-6 border-t border-gray-100">
                <div class="flex items-center justify-between gap-3 mb-3">
                    <p class="text-xs font-semibold text-gray-500">
                        Penanggung jawab <span class="text-red-400">*</span>
                    </p>
                    <span id="pj-progress"
                        class="text-[11px] font-semibold rounded-full px-2 py-0.5 bg-gray-50 text-gray-400 transition">
                        0/3 dipilih
                    </span>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">PPK</label>
                        <div class="relative">
                            <select name="ppk_id" required data-placeholder="Cari PPK..."
                                class="js-searchable w-full appearance-none bg-none border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition bg-white">
                                <option value="" disabled {{ $vPpk ? '' : 'selected' }}>— Pilih —</option>
                                @forelse ($ppkList as $p)
                                    <option value="{{ $p->id }}" {{ $vPpk == $p->id ? 'selected' : '' }}>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel PPK</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-3.5 w-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">Bendahara</label>
                        <div class="relative">
                            <select name="bendahara_id" required data-placeholder="Cari Bendahara..."
                                class="js-searchable w-full appearance-none bg-none border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition bg-white">
                                <option value="" disabled {{ $vBendahara ? '' : 'selected' }}>— Pilih —</option>
                                @forelse ($bendaharaList as $p)
                                    <option value="{{ $p->id }}" {{ $vBendahara == $p->id ? 'selected' : '' }}>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel Bendahara</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-3.5 w-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs text-gray-400 mb-1.5">Penanggung Jawab Kegiatan</label>
                        <div class="relative">
                            <select name="penanggung_jawab_id" required data-placeholder="Cari Penanggung Jawab..."
                                class="js-searchable w-full appearance-none bg-none border border-gray-200 rounded-lg px-3 py-2.5 text-sm focus:border-blue-400 focus:ring-1 focus:ring-blue-400 outline-none transition bg-white">
                                <option value="" disabled {{ $vPj ? '' : 'selected' }}>— Pilih —</option>
                                @forelse ($pjList as $p)
                                    <option value="{{ $p->id }}" {{ $vPj == $p->id ? 'selected' : '' }}>
                                        {{ $p->nama_gelar ?? $p->nama }}
                                    </option>
                                @empty
                                    <option value="" disabled>Belum ada pegawai berlabel ini</option>
                                @endforelse
                            </select>
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="h-3.5 w-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                            </svg>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ===== Tombol aksi ===== --}}
    <div class="flex items-center justify-between mt-6">
        <a href="{{ $isEdit ? route('agendas.show', $agenda) : route('agendas.index') }}"
            class="text-sm text-gray-400 hover:text-gray-600 transition">
            &larr; Batal
        </a>
        <button type="submit"
            class="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold px-5 py-2.5 rounded-lg text-sm shadow-md shadow-blue-600/20 transition">
            @if ($isEdit)
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                Simpan Perubahan
            @else
                Lanjut ke Rincian Biaya
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
                    stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
            @endif
        </button>
    </div>
</form>

<script>
    // State section "Anggaran & Administrasi" — dideklarasikan paling atas supaya
    // aman dipakai fungsi mana pun di bawah (tidak bergantung urutan pemanggilan).
    let anggaranOpen = true;

    // Pas render pertama (mis. halaman edit, peserta sudah tercentang dari awal),
    // highlight "field baru muncul" jangan nyala — highlight cuma untuk perubahan
    // akibat klik user.
    let initialRender = true;

    /**
     * Konfirmasi pakai SweetAlert2 (sudah dimuat lewat layout app.blade.php).
     * Cuma kepanggil kalau ada peserta yang punya rincian biaya (data-has-biaya="1"),
     * jadi di halaman create fungsi ini praktis tidak pernah jalan.
     *
     * Swal.fire() itu ASYNC (beda sama confirm() browser), makanya pakai callback.
     */
    function confirmHapusPesertaBerbiaya(onConfirm) {
        const warningIconSvg = `
            <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="50" cy="50" r="46" fill="#FEF2F2"/>
                <path d="M50 26L84 84H16L50 26Z" fill="#EF4444"/>
                <rect x="46" y="46" width="8" height="20" rx="4" fill="#FEF2F2"/>
                <rect x="46" y="70" width="8" height="8" rx="4" fill="#FEF2F2"/>
            </svg>
        `;

        Swal.fire({
            html: `
                <div class="swal-delete-icon-wrap">${warningIconSvg}</div>
                <div class="swal-delete-title">Peserta ini punya rincian biaya</div>
                <div class="swal-delete-text">Kalau di-uncek, data biayanya bakal ikut hilang pas disimpan. Lanjut?</div>
            `,
            showCancelButton: true,
            confirmButtonText: 'Lanjut',
            cancelButtonText: 'Batal',
            reverseButtons: true,
            buttonsStyling: false,
            focusConfirm: false,
            customClass: {
                popup: 'swal-delete-popup',
                actions: 'swal-delete-actions',
                confirmButton: 'swal-btn-confirm',
                cancelButton: 'swal-btn-cancel',
            },
        }).then(function (result) {
            if (result.isConfirmed && typeof onConfirm === 'function') {
                onConfirm();
            }
        });
    }

    // ==== Tab switcher (PNS / Non PNS) ====
    function showPesertaPanel(key) {
        document.querySelectorAll('[data-peserta-panel]').forEach(function (panel) {
            panel.classList.toggle('hidden', panel.dataset.pesertaPanel !== key);
        });
        document.querySelectorAll('.peserta-tab-btn').forEach(function (btn) {
            const active = btn.dataset.tab === key;
            btn.classList.toggle('border-blue-600', active);
            btn.classList.toggle('text-blue-600', active);
            btn.classList.toggle('border-transparent', !active);
            btn.classList.toggle('text-gray-400', !active);
            const badge = btn.querySelector('.peserta-tab-badge');
            if (badge) {
                badge.classList.toggle('bg-blue-50', active);
                badge.classList.toggle('text-blue-500', active);
                badge.classList.toggle('bg-gray-100', !active);
                badge.classList.toggle('text-gray-400', !active);
            }
        });
    }

    document.querySelectorAll('.peserta-tab-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            showPesertaPanel(btn.dataset.tab);
        });
    });

    // ==== Highlight singkat untuk field yang baru muncul karena pilihan peserta ====
    function flashField(wrap) {
        if (!wrap) return;
        wrap.classList.add('ring-2', 'ring-blue-300', 'ring-offset-4');
        setTimeout(function () {
            wrap.classList.remove('ring-2', 'ring-blue-300', 'ring-offset-4');
        }, 1500);
    }

    // Ubah visibilitas wrapper; kalau barusan berubah dari hidden -> tampil, kasih highlight
    // (kecuali pada render pertama). Return true kalau memang baru muncul.
    function setWrapVisible(wrap, visible) {
        const wasHidden = wrap.classList.contains('hidden');
        wrap.classList.toggle('hidden', !visible);
        if (visible && wasHidden) {
            if (!initialRender) flashField(wrap);
            return true;
        }
        return false;
    }

    // ==== Muncul/ilang field Nomor ST Khusus (Eselon I/II) sesuai peserta yg dicentang ====
    // (id & name field tetap "nomor-st-karo-*" / "nomor_st_karo" karena controller & DB masih pakai nama itu)
    function toggleNomorStKaro(checked) {
        const wrap = document.getElementById('nomor-st-karo-wrap');
        const namaLabel = document.getElementById('nomor-st-karo-nama');
        const input = document.getElementById('nomor-st-karo-input');
        if (!wrap) return;

        const khusus = checked.filter(function (cb) { return cb.dataset.stKhusus === '1'; });
        const adaKhusus = khusus.length > 0;

        setWrapVisible(wrap, adaKhusus);
        if (namaLabel) {
            namaLabel.textContent = adaKhusus
                ? '(' + khusus.map(function (cb) { return cb.dataset.namaPegawai; }).join(', ') + ')'
                : '';
        }
        // required cuma aktif kalau field-nya kelihatan (ada peserta Eselon I/II yg dicentang) —
        // biar gak nahan submit gara-gara field yg lagi disembunyiin.
        if (input) {
            input.required = adaKhusus;
        }
        syncAnggaranHeight();
    }

    // ==== Nomor Memo PNS/Non-PNS cuma diminta sesuai status peserta yg dicentang ====
    function toggleNomorMemoFields(checked) {
        const pnsWrap = document.getElementById('nomor-memo-pns-wrap');
        const pnsInput = document.getElementById('nomor-memo-pns-input');
        const nonPnsWrap = document.getElementById('nomor-memo-non-pns-wrap');
        const nonPnsInput = document.getElementById('nomor-memo-non-pns-input');
        if (!pnsWrap || !nonPnsWrap) return;

        function statusOf(cb) {
            const panel = cb.closest('[data-peserta-panel]');
            return panel ? panel.dataset.pesertaPanel : null;
        }

        const adaPns = checked.some(function (cb) { return statusOf(cb) === 'pns'; });
        const adaNonPns = checked.some(function (cb) { return statusOf(cb) === 'nonpns'; });

        setWrapVisible(pnsWrap, adaPns);
        setWrapVisible(nonPnsWrap, adaNonPns);
        if (pnsInput) pnsInput.required = adaPns;
        if (nonPnsInput) nonPnsInput.required = adaNonPns;

        syncAnggaranHeight();
    }

    // ==== Counter "X dipilih" + chip peserta terpilih (nempel di atas list) ====
    function updatePesertaCount() {
        const checked = Array.from(document.querySelectorAll('.peserta-checkbox:checked'));

        toggleNomorStKaro(checked);
        toggleNomorMemoFields(checked);

        const counter = document.getElementById('peserta-count');
        if (counter) counter.textContent = checked.length + ' dipilih';

        const chipsWrap = document.getElementById('peserta-selected-chips');
        if (!chipsWrap) return;

        if (checked.length === 0) {
            chipsWrap.classList.add('hidden');
            chipsWrap.innerHTML = '';
            return;
        }

        chipsWrap.classList.remove('hidden');
        chipsWrap.innerHTML = '';
        checked.forEach(function (cb) {
            // pakai data-nama-pegawai (bukan selector DOM) supaya tidak rusak kalau struktur label berubah
            const nama = cb.dataset.namaPegawai ?? '';
            const chip = document.createElement('span');
            chip.className = 'inline-flex items-center gap-1 bg-blue-50 text-blue-700 text-xs font-medium pl-2.5 pr-1.5 py-1 rounded-full';
            chip.innerHTML = '<span></span><button type="button" class="hover:bg-blue-100 rounded-full p-0.5 transition" aria-label="Hapus">'
                + '<svg xmlns="http://www.w3.org/2000/svg" class="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>'
                + '</button>';
            chip.querySelector('span').textContent = nama;
            chip.querySelector('button').addEventListener('click', function () {
                if (cb.dataset.hasBiaya === '1') {
                    confirmHapusPesertaBerbiaya(function () {
                        cb.checked = false;
                        updatePesertaCount();
                    });
                    return;
                }
                cb.checked = false;
                updatePesertaCount();
            });
            chipsWrap.appendChild(chip);
        });
    }

    // ==== Search + filter Unit Kerja, gabung jadi satu fungsi, auto-pindah tab kalau tab aktif kosong ====
    const pesertaSearch = document.getElementById('peserta-search');
    const pesertaSearchClear = document.getElementById('peserta-search-clear');
    const pesertaUnitFilter = document.getElementById('peserta-unit-filter');
    const pesertaSelectAllLabel = document.querySelector('.peserta-select-all-label');

    function applyPesertaFilters() {
        const keyword = (pesertaSearch?.value ?? '').trim().toLowerCase();
        const unit = pesertaUnitFilter?.value ?? '';
        const filterActive = Boolean(keyword || unit);
        const visibleCountByGroup = {};

        if (pesertaSearchClear) pesertaSearchClear.classList.toggle('hidden', !keyword);

        document.querySelectorAll('[data-peserta-panel]').forEach(function (panel) {
            const group = panel.dataset.pesertaPanel;
            const items = panel.querySelectorAll('.peserta-item');
            let visibleCount = 0;

            items.forEach(function (item) {
                const matchNama = !keyword || item.dataset.nama.includes(keyword);
                const matchUnit = !unit || item.dataset.unit === unit;
                const match = matchNama && matchUnit;
                item.classList.toggle('hidden', !match);
                if (match) visibleCount++;
            });

            visibleCountByGroup[group] = visibleCount;

            const emptyMsg = panel.querySelector('.peserta-empty-search');
            if (emptyMsg) {
                emptyMsg.classList.toggle('hidden', items.length === 0 || visibleCount > 0);
            }
        });

        // Sinkronkan badge angka di tab dengan hasil filter yang sedang tampil,
        // supaya "PNS 12" ikut berubah jadi "PNS 3" saat difilter — bukan tetap diam.
        document.querySelectorAll('.peserta-tab-btn').forEach(function (btn) {
            const badge = btn.querySelector('.peserta-tab-badge');
            if (!badge) return;
            badge.textContent = visibleCountByGroup[btn.dataset.tab];
        });

        if (pesertaSelectAllLabel) {
            pesertaSelectAllLabel.textContent = filterActive ? 'Pilih semua (hasil filter)' : 'Pilih semua';
        }

        // kalau tab yang lagi aktif hasilnya nihil, tapi tab satunya ada hasil, pindahin otomatis
        if (filterActive) {
            const activePanel = document.querySelector('[data-peserta-panel]:not(.hidden)');
            const activeGroup = activePanel?.dataset.pesertaPanel;
            if (activeGroup && visibleCountByGroup[activeGroup] === 0) {
                const otherGroup = Object.keys(visibleCountByGroup).find(function (g) {
                    return g !== activeGroup && visibleCountByGroup[g] > 0;
                });
                if (otherGroup) showPesertaPanel(otherGroup);
            }
        }
    }

    if (pesertaSearch) pesertaSearch.addEventListener('input', applyPesertaFilters);
    if (pesertaUnitFilter) pesertaUnitFilter.addEventListener('change', applyPesertaFilters);
    if (pesertaSearchClear) {
        pesertaSearchClear.addEventListener('click', function () {
            if (!pesertaSearch) return;
            pesertaSearch.value = '';
            pesertaSearch.focus();
            applyPesertaFilters();
        });
    }
    document.querySelectorAll('.peserta-reset-filters').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (pesertaSearch) pesertaSearch.value = '';
            if (pesertaUnitFilter) pesertaUnitFilter.value = '';
            applyPesertaFilters();
        });
    });

    // ==== "Pilih semua" — hanya menyentuh baris yang lagi terlihat di tab aktif ====
    const selectAllToggle = document.querySelector('.peserta-select-all');
    if (selectAllToggle) {
        selectAllToggle.addEventListener('change', function () {
            const activePanel = document.querySelector('[data-peserta-panel]:not(.hidden)');
            if (!activePanel) return;
            activePanel.querySelectorAll('.peserta-checkbox').forEach(function (cb) {
                const item = cb.closest('.peserta-item');
                if (!item || item.classList.contains('hidden')) return;

                // Batalin unchecking otomatis kalau peserta ini udah punya biaya —
                // biar "pilih semua" (nge-uncheck) gak diam-diam ngapus data.
                if (!selectAllToggle.checked && cb.checked && cb.dataset.hasBiaya === '1') {
                    return;
                }
                cb.checked = selectAllToggle.checked;
            });
            updatePesertaCount();
        });
    }

    // ==== Warning sebelum uncek peserta yang udah punya rincian biaya ====
    document.querySelectorAll('.peserta-checkbox').forEach(function (cb) {
        cb.addEventListener('change', function () {
            if (!cb.checked && cb.dataset.hasBiaya === '1') {
                // Balikin checked dulu SEMENTARA nunggu keputusan user — soalnya
                // Swal.fire() itu async. Kalau gak dibalikin dulu, checkbox & chip-nya
                // sempat "kelihatan" ke-uncek duluan sebelum dialognya kejawab.
                cb.checked = true;
                confirmHapusPesertaBerbiaya(function () {
                    cb.checked = false;
                    updatePesertaCount();
                });
                return;
            }
            updatePesertaCount();
        });
    });

    // ==== Section "Anggaran & Administrasi" bisa dilipat ====

    // Dipanggil tiap kali ada field di dalamnya yang muncul/hilang, biar tinggi
    // kontainernya ikut nyesuaiin dan isinya gak kepotong.
    function syncAnggaranHeight() {
        const body = document.getElementById('anggaran-body');
        if (body && anggaranOpen) {
            body.style.maxHeight = 'none';
            // overflow visible lagi tiap kali dipanggil selagi section kebuka, soalnya
            // beberapa pemicu (toggleNomorStKaro, dll) bisa nambah tinggi konten setelahnya
            body.style.overflow = 'visible';
        }
    }

    (function () {
        const btn = document.getElementById('anggaran-toggle');
        const body = document.getElementById('anggaran-body');
        const chevron = document.getElementById('anggaran-chevron');
        if (!btn || !body) return;

        function setOpen(next) {
            anggaranOpen = next;
            btn.setAttribute('aria-expanded', next);
            if (chevron) chevron.style.transform = next ? 'rotate(180deg)' : 'rotate(0deg)';

            if (next) {
                // overflow-hidden cuma dipakai SELAMA transisi buka, biar animasinya mulus
                body.style.overflow = 'hidden';
                body.style.maxHeight = body.scrollHeight + 'px';
                body.style.opacity = '1';
                // lepas ke 'none' + overflow visible setelah animasi kelar, supaya dropdown
                // & field yang muncul belakangan (termasuk dropdown searchable MAK/Petugas
                // Verifikasi/PIC yang kalau kepotong overflow-hidden jadi kelihatan kosong)
                // gak ketahan/kepotong tinggi kontainernya.
                setTimeout(function () {
                    if (anggaranOpen) {
                        body.style.maxHeight = 'none';
                        body.style.overflow = 'visible';
                    }
                }, 320);
            } else {
                // balik ke hidden dulu sebelum nutup, soalnya pas kebuka overflow-nya
                // sempat dilepas ke visible — transisi ketutup butuh overflow-hidden lagi
                body.style.overflow = 'hidden';
                body.style.maxHeight = body.scrollHeight + 'px';
                void body.offsetHeight; // paksa reflow biar transisi jalan
                body.style.maxHeight = '0px';
                body.style.opacity = '0';
            }
        }

        btn.addEventListener('click', function () { setOpen(!anggaranOpen); });

        // default kebuka; ganti ke setOpen(false) kalau mau default terlipat
        setOpen(true);
    })();

    // ==== Kalau validasi browser menolak submit gara-gara field di section Anggaran
    // yang lagi terlipat, buka otomatis lalu arahkan fokus ke field-nya. ====
    // Pakai capture (true) karena event "invalid" tidak bubble.
    document.getElementById('agenda-form').addEventListener('invalid', function (e) {
        const body = document.getElementById('anggaran-body');
        if (!body || !body.contains(e.target) || anggaranOpen) return;

        document.getElementById('anggaran-toggle').click();
        const target = e.target;
        setTimeout(function () {
            target.scrollIntoView({ behavior: 'smooth', block: 'center' });
            target.focus({ preventScroll: true });
        }, 350);
    }, true);

    // ==== Badge progres penanggung jawab ====
    (function () {
        const badge = document.getElementById('pj-progress');
        const selects = ['ppk_id', 'bendahara_id', 'penanggung_jawab_id']
            .map(function (n) { return document.querySelector('[name="' + n + '"]'); })
            .filter(Boolean);
        if (!badge || !selects.length) return;

        function render() {
            const terisi = selects.filter(function (s) { return s.value; }).length;
            const lengkap = terisi === selects.length;
            badge.textContent = terisi + '/' + selects.length + ' dipilih';
            badge.classList.toggle('bg-blue-50', lengkap);
            badge.classList.toggle('text-blue-600', lengkap);
            badge.classList.toggle('bg-gray-50', !lengkap);
            badge.classList.toggle('text-gray-400', !lengkap);
        }

        selects.forEach(function (s) { s.addEventListener('change', render); });
        render();
    })();

    // ==== Tanggal selesai gak boleh mundur dari tanggal mulai + info durasi ====
    (function () {
        const mulai = document.getElementById('tanggal-mulai');
        const selesai = document.getElementById('tanggal-selesai');
        const info = document.getElementById('durasi-info');
        if (!mulai || !selesai) return;

        function sync() {
            if (mulai.value) selesai.min = mulai.value;
            if (mulai.value && selesai.value && selesai.value < mulai.value) {
                selesai.value = mulai.value;
            }

            if (!info) return;
            if (mulai.value && selesai.value) {
                const hari = Math.round((new Date(selesai.value) - new Date(mulai.value)) / 86400000) + 1;
                info.textContent = hari + ' hari perjalanan';
                info.classList.remove('hidden');
            } else {
                info.classList.add('hidden');
            }
        }

        mulai.addEventListener('change', sync);
        selesai.addEventListener('change', sync);
        sync();
    })();

    updatePesertaCount();
    initialRender = false;
    applyPesertaFilters();
</script>