<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Memo {{ $statusLabel ?? '' }} - {{ $agenda->tujuan ?? '' }}</title>
    <style>
        @page {
            margin: 40px 60px;
        }

        body {
            font-family: Arial, sans-serif;
            font-size: 13px;
            color: #000;
        }

        .header-table {
            width: 100%;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 14px;
        }

        .header-table td {
            vertical-align: middle;
        }

        .logo {
            width: 110px;
            height: auto;
            padding-right: 30px;
        }

        .org-name {
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            line-height: 1.3;
        }

        .org-address {
            text-align: center;
            font-size: 13px;
            line-height: 1.5;
        }

        .title {
            text-align: center;
            font-weight: bold;
            font-size: 13px;
            margin: 14px 0 2px;
        }

        .subtitle {
            text-align: center;
            font-size: 13px;
            font-weight: bold;
            margin-bottom: 14px;
        }

        table.info {
            width: 100%;
            margin-bottom: 10px;
        }

        .divider {
            border-bottom: 2px solid #000;
            margin: 4px 0 14px;
        }

        table.info td {
            vertical-align: top;
            padding: 1px 0;
        }

        table.info td.label {
            width: 90px;
        }

        table.info td.colon {
            width: 12px;
        }

        .isi {
            text-align: justify;
            text-indent: 2em;
            margin: 14px 0 6px;
            line-height: 1.6;
        }

        .isi-closing {
            text-indent: 2em;
            margin: 0 0 20px;
            line-height: 1.6;
        }

        /* Blok tanda tangan: rata kanan */
        .ttd-block {
            margin-top: 10px;
            width: 280px;
            margin-left: auto;
            margin-right: 0;
            text-align: left;
            line-height: 1.5;
        }

        .ttd-block .signer-name {
            padding-top: 80px;
            font-weight: bold;
            text-decoration: underline;
        }

        table.lampiran {
            width: 100%;
            border-collapse: collapse;
            margin-top: 6px;
        }

        table.lampiran th,
        table.lampiran td {
            border: 1px solid #000;
            padding: 4px 6px;
            font-size: 13px;
        }

        table.lampiran th {
            background: #f0f0f0;
            text-align: center;
        }

        table.terbilang {
            width: 100%;
            border-collapse: collapse;
            margin-top: 12px;
        }

        table.terbilang td {
            border: none;
            padding: 6px 8px;
            font-size: 12px;
        }

        table.terbilang td.label {
            width: 140px;
        }

        table.terbilang td.colon {
            width: 14px;
        }

        table.terbilang td.value {
            background: #e0e0e0;
        }

        .text-right {
            text-align: right;
        }

        .text-center {
            text-align: center;
        }

        .page-break {
            page-break-after: always;
        }

        .ttd-row {
            width: 100%;
            margin-top: 30px;
            margin-right: 20px;
        }

        .ttd-row td {
            width: 50%;
            text-align: center;
            vertical-align: top;
            padding-top: 10px;
        }

        /* Jarak baris kedua ke baris pertama tanda tangan */
        .ttd-row tr:nth-child(2) td {
            padding-top: 50px;
        }

        .ttd-jabatan {
            min-height: 32px;
        }

        .ttd-nip {
            margin-top: 2px;
        }

        .ttd-name {
            margin-top: 80px;
            text-decoration: underline;
        }

        /* ===== Halaman 3: Lampiran Memorandum ===== */
        table.lamp3 {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 24px;
        }

        table.lamp3 th,
        table.lamp3 td {
            border: 1px solid #000;
            padding: 3px 5px;
            font-size: 13px;
        }

        table.lamp3 th {
            background: #f0f0f0;
            text-align: center;
        }

        table.rp {
            width: 100%;
            border-collapse: collapse;
        }

        table.lamp3 table.rp td {
            border: none;
            padding: 0;
        }

        .lamp3-box {
            border: 1px solid #000;
            border-top: none;
            padding: 18px 6px;
            font-size: 13px;
        }
    </style>
</head>

<body>
    @include('pdf._tanda-sistem')

    {{-- ================= HALAMAN 1: MEMORANDUM ================= --}}
    <table class="header-table">
        <tr>
            <td style="text-align:left;">
                <table style="margin:0 0 0 40px; border-collapse:collapse;">
                    <tr>
                        <td class="logo">
                            <img src="{{ public_path('images/logo.png') }}" class="logo">
                        </td>
                        <td>
                            <div class="org-name">KEMENTERIAN KOORDINATOR BIDANG PANGAN<br>REPUBLIK INDONESIA</div>
                            <div class="org-address">Graha Mandiri, Jl. Imam Bonjol No. 61, Jakarta Pusat
                                10310<br>Email:
                                kemenkopangan@kemenkopangan.go.id</div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    <div class="title">MEMORANDUM</div>
    <div class="subtitle">Nomor : {{ $nomorMemo }}</div>

    <table class="info">
        <tr>
            <td class="label">Yth</td>
            <td class="colon">:</td>
            <td>Kuasa Pengguna Anggaran</td>
        </tr>
        <tr>
            <td class="label">Dari</td>
            <td class="colon">:</td>
            <td>{{ $agenda->dari_memo ?: 'Pejabat Pembuat Komitmen Biro Manajemen Kinerja, Data dan Informasi' }}</td>
        </tr>
        <tr>
            <td class="label">Hal</td>
            <td class="colon">:</td>
            <td>{{ $halMemo ?? 'Permintaan Pembayaran Langsung (LS) Perjalanan Dinas' }}</td>
        </tr>
        <tr>
            <td class="label">Lampiran</td>
            <td class="colon">:</td>
            <td>
                @if (!empty($lampiranMemo))
                    {{ $lampiranMemo }}
                @else
                    1. Surat Keputusan<br>
                    2. Rincian Biaya Kegiatan<br>
                    3. Daftar Nominatif
                @endif
            </td>
        </tr>
        <tr>
            <td class="label">Tanggal</td>
            <td class="colon">:</td>
            <td>{{ \Carbon\Carbon::now()->translatedFormat('d F Y') }}</td>
        </tr>
    </table>

    <div class="divider"></div>

    @php
        // Hindari kalimat "Sehubungan dengan Sehubungan dengan ..."
        $uraianBersih = trim(preg_replace('/^sehubungan\s+dengan\s+/i', '', trim($uraianMemo)));
    @endphp
    <div class="isi">
        Sehubungan dengan {{ $uraianBersih }}, dengan ini kami mengajukan permohonan dana sebesar
        Rp{{ number_format($totalBiaya, 0, ',', '.') }} yang dibebankan pada APBN satuan kerja
        Kementerian Koordinator Bidang Pangan tahun anggaran {{ \Carbon\Carbon::now()->year }}
        dengan MAK.{{ $agenda->mak }}
    </div>

    <div class="isi-closing">Atas perhatian dan kerjasamanya, kami ucapkan terimakasih.</div>

    <div class="ttd-block">
        <div class="jabatan">Pejabat Pembuat Komitmen,</div>
        <div class="signer-name">{{ $agenda->ppk->nama ?? '.....................' }}</div>
    </div>

    <div class="page-break"></div>

    {{-- ================= HALAMAN 2: LAMPIRAN SURAT ================= --}}
    <div style="font-weight:bold; font-size:14px; margin-bottom:10px;">LAMPIRAN SURAT</div>

    <table class="info" style="margin-bottom: 6px;">
        <tr>
            <td class="label">Nomor</td>
            <td class="colon">:</td>
            <td>{{ $nomorMemo }}</td>
        </tr>
        <tr>
            <td class="label">Tanggal</td>
            <td class="colon">:</td>
            <td>{{ \Carbon\Carbon::now()->translatedFormat('d F Y') }}</td>
        </tr>
    </table>

    <table class="lampiran">
        <thead>
            <tr>
                <th style="width:110px;">Kegiatan, Output, Komponen, Sub</th>
                <th>Uraian</th>
                <th style="width:90px;">Jumlah (Rp.)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>{{ $agenda->kode_giat }}</td>
                <td>{{ $agenda->uraian_giat }}</td>
                <td></td>
            </tr>
            <tr>
                <td>{{ $agenda->kode_komponen }}</td>
                <td>{{ $agenda->uraian_komponen }}</td>
                <td></td>
            </tr>
            <tr>
                <td>{{ $agenda->kode_akun_ap }}</td>
                <td>{{ $agenda->uraian_akun_ap }}</td>
                <td></td>
            </tr>
            <tr>
                <td>{{ $agenda->kode_belanja }}</td>
                <td>
                    {{ $agenda->uraian_belanja }}
                    @if(!empty($rincianBiaya))
                        <br>
                        @foreach ($rincianBiaya as $itemBiaya)
                            - {{ $itemBiaya }}<br>
                        @endforeach
                    @endif
                </td>
                <td class="text-right"><strong>Rp.{{ number_format($totalBiaya, 0, ',', '.') }}</strong></td>
            </tr>
        </tbody>
    </table>

    {{-- Rincian item (otomatis bertambah sesuai item yang dipilih). Hanya untuk memo langsung. --}}
    @if(!empty($itemLampiran))
        <table class="lampiran" style="margin-top:8px;">
            <thead>
                <tr>
                    <th style="width:110px;">Item</th>
                    <th>Uraian</th>
                    <th style="width:90px;">Jumlah (Rp.)</th>
                </tr>
            </thead>
            <tbody>
                @foreach($itemLampiran as $it)
                    <tr>
                        <td>{{ $it['kode'] }}</td>
                        <td>{{ $it['uraian'] }}</td>
                        <td class="text-right">Rp.{{ number_format((int) $it['jumlah'], 0, ',', '.') }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    @php
        // Fallback: hitung terbilang otomatis kalau controller belum kirim.
        if (empty($terbilang)) {
            $terbilangFn = function ($angka) use (&$terbilangFn) {
                $angka = (int) abs($angka);
                $huruf = [
                    '',
                    'Satu',
                    'Dua',
                    'Tiga',
                    'Empat',
                    'Lima',
                    'Enam',
                    'Tujuh',
                    'Delapan',
                    'Sembilan',
                    'Sepuluh',
                    'Sebelas'
                ];

                if ($angka < 12) {
                    return $huruf[$angka];
                } elseif ($angka < 20) {
                    return $terbilangFn($angka - 10) . ' Belas';
                } elseif ($angka < 100) {
                    return trim($terbilangFn((int) ($angka / 10)) . ' Puluh ' . $terbilangFn($angka % 10));
                } elseif ($angka < 200) {
                    return trim('Seratus ' . $terbilangFn($angka - 100));
                } elseif ($angka < 1000) {
                    return trim($terbilangFn((int) ($angka / 100)) . ' Ratus ' . $terbilangFn($angka % 100));
                } elseif ($angka < 2000) {
                    return trim('Seribu ' . $terbilangFn($angka - 1000));
                } elseif ($angka < 1000000) {
                    return trim($terbilangFn((int) ($angka / 1000)) . ' Ribu ' . $terbilangFn($angka % 1000));
                } elseif ($angka < 1000000000) {
                    return trim($terbilangFn((int) ($angka / 1000000)) . ' Juta ' . $terbilangFn($angka % 1000000));
                } elseif ($angka < 1000000000000) {
                    return trim($terbilangFn((int) ($angka / 1000000000)) . ' Miliar ' . $terbilangFn($angka % 1000000000));
                }

                return trim($terbilangFn((int) ($angka / 1000000000000)) . ' Triliun ' . $terbilangFn($angka % 1000000000000));
            };

            $terbilang = trim(preg_replace('/\s+/', ' ', $terbilangFn($totalBiaya))) . ' Rupiah';
        }
    @endphp
    <table class="terbilang">
        <tr>
            <td class="label">Terbilang</td>
            <td class="colon">:</td>
            <td class="value"><strong>{{ $terbilang }}</strong></td>
        </tr>
    </table>

    <table class="ttd-row">
        <tr>
            <td>
                <div class="ttd-jabatan">Bendahara Pengeluaran,</div>
                <div class="ttd-name">{{ $agenda->bendahara->nama ?? '.....................' }}</div>
                @if(!empty($agenda->bendahara->nip))
                    <div class="ttd-nip">NIP {{ $agenda->bendahara->nip }}</div>
                @endif
            </td>
            <td>
                <div class="ttd-jabatan">Penanggung Jawab Kegiatan,</div>
                <div class="ttd-name">{{ $agenda->penanggungJawab->nama ?? '.....................' }}</div>
                @if(!empty($agenda->penanggungJawab->nip))
                    <div class="ttd-nip">NIP {{ $agenda->penanggungJawab->nip }}</div>
                @endif
            </td>
        </tr>
        <tr>
            <td>
                <div class="ttd-jabatan">Mengetahui/menyetujui<br>Pejabat Pembuat Komitmen</div>
                <div class="ttd-name">{{ $agenda->ppk->nama ?? '.....................' }}</div>
                @if(!empty($agenda->ppk->nip))
                    <div class="ttd-nip">NIP {{ $agenda->ppk->nip }}</div>
                @endif
            </td>
            <td>
                <div class="ttd-jabatan">Petugas Verifikasi,</div>
                <div class="ttd-name">{{ $agenda->petugasVerifikasi->nama ?? '.....................' }}</div>
                @if(!empty($agenda->petugasVerifikasi->nip))
                    <div class="ttd-nip">NIP {{ $agenda->petugasVerifikasi->nip }}</div>
                @endif
            </td>
        </tr>
    </table>

    {{-- ================= HALAMAN 3: LAMPIRAN MEMORANDUM ================= --}}
    {{-- Tampil hanya kalau controller mengirim variabel $lampiran --}}
    @if(!empty($lampiran))
        <div class="page-break"></div>

        <div style="text-align:center; font-weight:bold; font-size:13px; margin-bottom:10px;">
            LAMPIRAN MEMORANDUM
        </div>
        <div style="text-align:center; font-weight:bold; font-size:13px; margin-bottom:2px;">
            {{ $lampiran['perihal'] }}
        </div>

        {{-- Tabel rincian item --}}
        <table class="lamp3">
            <tr>
                <th style="width:60%;"></th>
                <th>Item</th>
                <th style="width:100px;">Jumlah</th>
            </tr>
            @foreach($lampiran['items'] as $i => $it)
                <tr>
                    @if($i === 0)
                        <td rowspan="{{ count($lampiran['items']) }}" class="text-center"
                            style="vertical-align:middle; font-size:13px; font-weight:bold;">
                            {{ $agenda->mak }}
                        </td>
                    @endif
                    <td>{{ $it['item'] }}</td>
                    <td class="text-right">Rp{{ number_format($it['jumlah'], 0, '.', ',') }}</td>
                </tr>
            @endforeach
        </table>

        {{-- Tabel total bersih per pegawai --}}
        @php $grandTotal = collect($lampiran['pegawai'])->sum('total'); @endphp
        <table class="lamp3" style="margin-bottom:0;">
            <tr>
                <th style="width:50%;"></th>
                <th>Total Bersih</th>
            </tr>
            @foreach($lampiran['pegawai'] as $p)
                <tr>
                    <td style="padding:8px 5px;">{{ $p['nama'] }}</td>
                    <td class="text-center">Rp{{ number_format($p['total'], 0, '.', ',') }}</td>
                </tr>
            @endforeach
            <tr>
                <td style="padding:8px 5px;">TOTAL</td>
                <td class="text-center">Rp{{ number_format($grandTotal, 0, '.', ',') }}</td>
            </tr>
        </table>
        <div class="lamp3-box">{{ $lampiran['st_info'] }}</div>
        <div class="lamp3-box">Perihal: {{ $lampiran['perihal'] }}</div>
    @endif

    {{-- ================= HALAMAN 3 (memo langsung): LAMPIRAN MEMORANDUM ================= --}}
    {{-- Tampil hanya kalau controller mengirim $lampiranMandiri (memo_entries). Memo agenda memakai blok di atas. --}}
    @if(!empty($lampiranMandiri))
        @php
            $lm = $lampiranMandiri;
            $rp = fn ($n) => '<table class="rp"><tr><td>Rp</td><td style="text-align:right;">'
                . number_format((int) $n, 0, ',', '.') . '</td></tr></table>';
            $totalPengajuan = $lm['total_pengajuan'] ?? collect($lm['baris'])->sum('pengajuan');
        @endphp

        <div class="page-break"></div>

        <div style="text-align:center; font-weight:bold; font-size:13px; margin-bottom:10px;">LAMPIRAN MEMORANDUM</div>
        <div style="text-align:center; font-weight:bold; font-size:13px; margin-bottom:6px;">{{ $lm['perihal'] }}</div>

        <table class="lamp3" style="margin-bottom:18px;">
            <tr>
                <th>Kode Akun/Item</th>
                <th style="width:100px;">Pagu</th>
                <th style="width:100px;">Pengajuan</th>
                <th style="width:90px;">Klasifikasi<br>(TKDN, PDN, Impor)</th>
                <th style="width:60px;">Nilai %</th>
            </tr>
            @foreach($lm['baris'] as $b)
                <tr>
                    <td>{{ $b['kode'] }}</td>
                    <td>@if($b['pagu'] !== null){!! $rp($b['pagu']) !!}@else<div class="text-center">-</div>@endif</td>
                    <td>{!! $rp($b['pengajuan']) !!}</td>
                    <td class="text-center">{{ $b['klasifikasi'] }}</td>
                    <td class="text-center">{{ $b['nilai'] }}%</td>
                </tr>
            @endforeach
            <tr>
                <td class="text-center">TOTAL</td>
                <td></td>
                <td>{!! $rp($totalPengajuan) !!}</td>
                <td></td>
                <td></td>
            </tr>
        </table>

        <div style="text-align:center; font-weight:bold; font-size:13px; margin-bottom:6px;">RINCIAN TRANSFER</div>
        <table class="lamp3" style="margin-bottom:0;">
            <tr>
                <th>Nama</th>
                <th colspan="2">Keterangan Transfer</th>
                <th style="width:120px;">Total Bersih (Rp)</th>
            </tr>
            <tr>
                <td>{{ $lm['penerima']['nama'] ?: '-' }}</td>
                <td class="text-center" style="width:90px;">{{ $lm['penerima']['bank'] ?: '-' }}</td>
                <td class="text-center" style="width:120px;">{{ $lm['penerima']['rekening'] ?: '-' }}</td>
                <td>{!! $rp($lm['penerima']['total_bersih']) !!}</td>
            </tr>
            <tr>
                <td colspan="3" class="text-right"><strong>Total</strong></td>
                <td>{!! $rp($lm['penerima']['total_bersih']) !!}</td>
            </tr>
        </table>
        <table class="lamp3" style="margin-bottom:0; margin-top:-1px;">
            <tr>
                <td style="width:60px; padding:5px;">ST</td>
                <td style="padding:5px;">{{ $lm['st_info'] }}</td>
            </tr>
            <tr>
                <td style="padding:18px 5px;">Perihal</td>
                <td style="padding:18px 5px;">{{ $lm['perihal'] }}</td>
            </tr>
        </table>
    @endif

</body>

</html>