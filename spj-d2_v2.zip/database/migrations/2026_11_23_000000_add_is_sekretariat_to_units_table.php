<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasColumn('units', 'is_sekretariat')) {
            Schema::table('units', function (Blueprint $table) {
                $table->boolean('is_sekretariat')->default(false);
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('units', 'is_sekretariat')) {
            Schema::table('units', function (Blueprint $table) {
                $table->dropColumn('is_sekretariat');
            });
        }
    }
};
