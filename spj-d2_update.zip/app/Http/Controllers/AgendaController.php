<?php

namespace App\Http\Controllers;

use App\Models\Agenda;
use App\Models\Pegawai;
use App\Models\DokumenUpload;
use App\Models\SbmRate;
use App\Models\SbmFlatRate;
use App\Models\PengRiilRate;
use App\Models\KabupatenKota;
use App\Models\MakOption;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Carbon\Carbon;
use App\Services\MakSisaService;
use App\Services\NomorMemoService;
use App\Services\MakUnitService;
use Illuminate\Validation\Rule;

class AgendaController extends Controller
{
    /**
     * Peta jenis uang harian (UH) ke pasangan kolom hari/rate di pivot agenda_pegawai.
     * Dipakai bersama oleh store() (default) dan pesertaStore() (simpan aktual).
     */
    private const UH_FIELD_MAP = [
        'uh_biasa' => ['hari' => 'hari_dinas_biasa', 'rate' => 'rate_dinas_biasa'],
        'uh_biasa_60' => ['hari' => 'hari_biasa_60', 'rate' => 'rate_biasa_60'],
        'uh_fullday' => ['hari' => 'hari_fullday', 'rate' => 'rate_fullday'],
        'uh_fullboard' => ['hari' => 'hari_fullboard', 'rate' => 'rate_fullboard'],
    ];

    /**
     * Daftar komponen biaya "simple" (satu nilai per peserta, di luar lumpsum)
     * yang bisa dipilih di chip "Komponen Biaya".
     */
    private const SIMPLE_KOMPONEN_FIELDS = [
        'tiket',
        'dukungan_transportasi',
        'transportasi_darat',
        'transportasi_lokal',
        'peng_riil',
        'hotel',
        'penginapan_30',
        'representatif',
        'belanja_bahan',
        'honor_narsum',
    ];

    /**
     * Nilai default kolom biaya pas peserta baru ter-attach ke agenda (baik dari
     * store() step 1, maupun dari update() kalau nambah peserta lewat edit).
     * Rinciannya baru diisi user di halaman Rincian Biaya.
     */
    private const DEFAULT_PIVOT_BIAYA = [
        'tiket' => null,
        'dukungan_transportasi' => null,
        'transportasi_darat' => null,
        'transportasi_lokal' => null,
        'peng_riil' => null,
        'peng_riil_mode' => 'manual',
        'peng_riil_rate_id' => null,
        'peng_riil_detail' => null,
        'hotel' => null,
        'penginapan_30' => null,
        'hari_dinas_biasa' => 0,
        'rate_dinas_biasa' => 0,
        'hari_biasa_60' => 0,
        'rate_biasa_60' => 0,
        'hari_fullday' => 0,
        'rate_fullday' => 0,
        'hari_fullboard' => 0,
        'rate_fullboard' => 0,
        'lumpsum' => 0,
        'representatif' => null,
        'belanja_bahan' => null,
        'honor_narsum' => null,
    ];

    public function index(Request $request)
    {
        // 'pic' ikut di-eager load (selain 'pegawai') supaya kartu detail
        // singkat di halaman index (klik baris utk expand) bisa nampilin
        // nama PIC tanpa nge-trigger query N+1 per baris.
        $agendas = Agenda::with(['pegawai', 'pic'])
            ->withCount('dokumenUploads')
            ->latest()
            ->get();

        $totalDokumenKategori = count(Agenda::KATEGORI_DOKUMEN);

        return view('agendas.index', compact('agendas', 'totalDokumenKategori'));
    }

    public function create()
    {
        $pegawaiList = Pegawai::orderBy('nama')->get();

        // Daftar provinsi buat dropdown "Tujuan" — sumbernya sama persis dengan
        // master rate SBM (sbm_rates), biar provinsi yg dipilih di sini otomatis
        // punya rate yg bisa dipatok nanti di halaman Rincian Biaya.
        $provinsiList = SbmRate::orderBy('provinsi')->pluck('provinsi');

        // Map provinsi -> list kab/kota, dikirim sekali sbg JSON buat dropdown
        // cascading di client (JS doang, gak perlu AJAX pas ganti provinsi).
        $kabKotaMap = KabupatenKota::orderBy('nama')->get()->groupBy('provinsi')
            ->map(fn($g) => $g->pluck('nama')->values());

        // MAK & field administrasi dipilih di step 3 (anggaranForm), bukan di sini.
        return view('agendas.create', compact('pegawaiList', 'provinsiList', 'kabKotaMap'));
    }

    public function store(Request $request)
    {
        // pic_id dan field anggaran/memo diisi di step 3 (anggaranStore()).
        $validated = $request->validate([
            'nomor_st' => 'required|string',
            'nomor_st_karo' => 'nullable|string',
            'uraian_kegiatan' => 'required|string',
            'tujuan' => 'required|string',
            'kota_tujuan' => 'required|string',
            'alat_angkut' => 'nullable|in:darat,udara,laut,darat_udara',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
            'ppk_id' => 'nullable|exists:pegawai,id',
            'bendahara_id' => 'nullable|exists:pegawai,id',
            'penanggung_jawab_id' => 'nullable|exists:pegawai,id',
            'pegawai_id' => 'required|array|min:1',
            'pegawai_id.*' => 'exists:pegawai,id',
        ], [
            'pegawai_id.required' => 'Pilih minimal satu peserta.',
        ]);

        // Catatan: komponen_biaya & jenis_uang_harian SENGAJA tidak divalidasi/diterima
        // di sini. Pemilihan komponen dilakukan di halaman "Rincian Biaya"
        // (step 2, lihat pesertaStore()), bukan di step 1 ini.

        $pegawaiIds = $validated['pegawai_id'];
        unset($validated['pegawai_id']);

        // Nomor ST Kepala Biro wajib kalau salah satu peserta yang dipilih jabatannya
        // Kepala Biro (sama persis logic deteksi yg dipakai AgendaPdfController@generateSpd).
        $this->ensureNomorStKaroFilled($pegawaiIds, $validated['nomor_st_karo'] ?? null);

        $agenda = Agenda::create($validated);

        // Attach peserta terpilih dengan biaya kosong dulu (default 0/null),
        // rinciannya baru diisi di halaman berikutnya (input biaya), sekalian
        // komponen biaya & rate-nya dipatok di sana.
        $syncData = [];
        foreach ($pegawaiIds as $pegawaiId) {
            $syncData[$pegawaiId] = self::DEFAULT_PIVOT_BIAYA;
        }
        $agenda->pegawai()->sync($syncData);

        return redirect()->route('agendas.peserta', $agenda)
            ->with('success', 'Agenda berhasil dibuat, lanjut pilih komponen & isi rincian biaya peserta.');
    }

    public function edit(Agenda $agenda)
    {
        $agenda->load('pegawai');

        $pegawaiList = Pegawai::orderBy('nama')->get();
        $ppkList = $pegawaiList;
        $bendaharaList = $pegawaiList;
        $pjList = $pegawaiList;

        // TODO: $picList & $makOptions dihapus (beserta dari compact di bawah)
        // setelah edit.blade.php tidak lagi memakainya / meng-include
        // partial administrasi-anggaran.
        $picList = $pegawaiList;
        $makOptions = MakOption::orderBy('mak')->get();

        $provinsiList = SbmRate::orderBy('provinsi')->pluck('provinsi');
        $kabKotaMap = KabupatenKota::orderBy('nama')->get()->groupBy('provinsi')
            ->map(fn($g) => $g->pluck('nama')->values());

        $selectedPesertaIds = $agenda->pegawai->pluck('id');
        $simpleFieldsCek = array_diff(self::SIMPLE_KOMPONEN_FIELDS, ['peng_riil']);
        $pesertaHasBiayaIds = $agenda->pegawai->filter(function ($p) use ($simpleFieldsCek) {
            $pivot = $p->pivot;

            // Komponen biaya "simple" (tiket, hotel, dst)
            foreach ($simpleFieldsCek as $field) {
                if (!empty($pivot->{$field})) {
                    return true;
                }
            }

            // Peng. Riil: dicek lewat total & detail entry-nya
            if (!empty($pivot->peng_riil) || !empty($pivot->peng_riil_detail)) {
                return true;
            }

            // Uang harian: hari yang sudah diisi, atau lumpsum > 0
            foreach (self::UH_FIELD_MAP as $map) {
                if (!empty($pivot->{$map['hari']})) {
                    return true;
                }
            }

            return !empty($pivot->lumpsum);
        })->pluck('id');

        return view('agendas.edit', compact(
            'agenda',
            'pegawaiList',
            'ppkList',
            'bendaharaList',
            'pjList',
            'picList',
            'provinsiList',
            'kabKotaMap',
            'makOptions',
            'selectedPesertaIds',
            'pesertaHasBiayaIds'
        ));
    }

    public function update(Request $request, Agenda $agenda)
    {
        $validated = $request->validate([
            'nomor_st' => 'required|string',
            'nomor_st_karo' => 'nullable|string',
            'uraian_kegiatan' => 'required|string',
            'tujuan' => 'required|string',
            'kota_tujuan' => 'nullable|string',
            'alat_angkut' => 'nullable|in:darat,udara,laut,darat_udara',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
            'ppk_id' => 'nullable|exists:pegawai,id',
            'bendahara_id' => 'nullable|exists:pegawai,id',
            'penanggung_jawab_id' => 'nullable|exists:pegawai,id',
            'pegawai_id' => 'required|array|min:1',
            'pegawai_id.*' => 'exists:pegawai,id',
        ], [
            'pegawai_id.required' => 'Pilih minimal satu peserta.',
        ]);

        // komponen_biaya, jenis_uang_harian, MAK, nomor memo & pic_id tidak diedit dari sini
        // (lihat pesertaStore() dan anggaranStore()) — dipertahankan apa adanya di $agenda.

        $pegawaiIds = collect($validated['pegawai_id'])->map(fn($id) => (int) $id);
        unset($validated['pegawai_id']);

        $this->ensureNomorStKaroFilled($pegawaiIds->all(), $validated['nomor_st_karo'] ?? null);

        // Dihitung sebelum update supaya penolakan di bawah tidak meninggalkan data setengah tersimpan.
        $currentPegawaiIds = $agenda->pegawai()->pluck('pegawai.id');
        $toDetach = $currentPegawaiIds->diff($pegawaiIds);
        $toAttach = $pegawaiIds->diff($currentPegawaiIds);

        // Menambah/mengurangi peserta mengubah total biaya memo. Kalau memo sudah
        // SAKTI/SP2D, angkanya sudah tercatat di SAKTI, jadi susunan peserta dikunci.
        if ($this->adaMemoTerkunci($agenda) && ($toDetach->isNotEmpty() || $toAttach->isNotEmpty())) {
            return redirect()->route('agendas.show', $agenda)
                ->with('warning', 'Peserta tidak bisa ditambah atau dikurangi karena memo sudah SAKTI/SP2D. '
                    . 'Mundurkan status memo dulu jika perlu koreksi.');
        }

        $agenda->update($validated);

        // Peserta lama yg sudah ter-attach TIDAK disentuh pivot-nya di sini (biar
        // rincian biaya yg udah diisi gak ke-reset) — cuma yg beneran nambah/kurang
        // yg diproses. Ini sengaja gak pakai sync() polos, karena sync() akan nulis
        // ulang kolom pivot yg gak disebutkan jadi default/null.
        if ($toDetach->isNotEmpty()) {
            $agenda->pegawai()->detach($toDetach);

            // Peserta berkurang -> total biaya berubah -> segarkan snapshot memo yang masih outstanding.
            $this->segarkanSnapshotMemo($agenda);
        }

        foreach ($toAttach as $pegawaiId) {
            $agenda->pegawai()->attach($pegawaiId, self::DEFAULT_PIVOT_BIAYA);
        }

        if ($toAttach->isNotEmpty()) {
            return redirect()->route('agendas.peserta', $agenda)
                ->with('success', 'Agenda berhasil diperbarui. Lengkapi rincian biaya untuk peserta baru.');
        }

        return redirect()->route('agendas.show', $agenda)
            ->with('success', 'Agenda berhasil diperbarui.');
    }

    public function show(Agenda $agenda)
    {
        $agenda->load(['pegawai', 'dokumenUploads']);
        $kategoriList = Agenda::KATEGORI_DOKUMEN;

        return view('agendas.show', compact('agenda', 'kategoriList'));
    }

    public function pesertaForm(Agenda $agenda)
    {
        $agenda->load('pegawai');

        // Hanya pegawai yang sudah dipilih sebagai peserta di step 1 (Buat Agenda)
        // yang ditampilkan di sini. Kalau kosong, artinya belum ada peserta terpilih.
        $pegawaiList = $agenda->pegawai;

        // Rate SBM sesuai provinsi tujuan agenda ini — dipakai buat patok rate UH
        // (readonly) & opsi "SBM" di toggle Peng. Riil. Null kalau provinsinya
        // belum ada di master data (blade & pesertaStore() sudah jaga2 utk ini).
        $sbmRate = SbmRate::forProvinsi($agenda->tujuan);
        $sbmFlat = SbmFlatRate::current();

        // Daftar rate transportasi buat popup Peng. Riil — dropdown-nya BEBAS
        // pilih tujuan (gak terikat Tujuan agenda), dikelompokkan per kategori
        // biar bisa dipisah jadi <optgroup> Provinsi / Jabodetabek di Blade.
        $pengRiilRates = PengRiilRate::orderBy('tujuan')->get()->groupBy('kategori');

        return view('agendas.peserta', compact('agenda', 'pegawaiList', 'sbmRate', 'sbmFlat', 'pengRiilRates'));
    }

    public function pesertaStore(Request $request, Agenda $agenda)
    {
        // Rincian biaya menentukan nominal memo. Kalau salah satu memo sudah SAKTI/SP2D,
        // angkanya sudah tercatat di SAKTI, jadi rincian tidak boleh berubah.
        if ($this->adaMemoTerkunci($agenda)) {
            return redirect()->route('agendas.show', $agenda)
                ->with('warning', 'Rincian biaya tidak bisa diubah karena memo sudah SAKTI/SP2D. '
                    . 'Mundurkan status memo dulu jika perlu koreksi.');
        }

        // Rentang surat tugas (batas tanggal peserta)
        $min = $agenda->tanggal_mulai->toDateString();
        $max = $agenda->tanggal_selesai->toDateString();

        // Komponen biaya & jenis UH dipilih di halaman ini (chip di atas tabel),
        // makanya divalidasi & disimpan di sini.
        $validated = $request->validate([
            'komponen_biaya' => 'required|array|min:1',
            'komponen_biaya.*' => 'string',

            // Wajib kalau komponen "lumpsum" dicentang, selain itu boleh kosong.
            'jenis_uang_harian' => [
                'nullable',
                'array',
                Rule::requiredIf(fn() => in_array('lumpsum', (array) $request->input('komponen_biaya', []))),
            ],
            'jenis_uang_harian.*' => ['string', Rule::in(array_keys(self::UH_FIELD_MAP))],

            'tanggal_mulai.*' => ['nullable', 'date', "after_or_equal:$min", "before_or_equal:$max"],
            'tanggal_selesai.*' => ['nullable', 'date', "after_or_equal:$min", "before_or_equal:$max"],
        ], [
            'komponen_biaya.required' => 'Pilih minimal satu komponen biaya.',
            'jenis_uang_harian.required' => 'Pilih minimal satu jenis uang harian karena komponen Uang Harian dicentang.',
            'jenis_uang_harian.*.in' => 'Jenis uang harian tidak valid.',
            'tanggal_mulai.*.after_or_equal' => 'Tanggal peserta tidak boleh sebelum rentang surat tugas.',
            'tanggal_mulai.*.before_or_equal' => 'Tanggal peserta tidak boleh melewati rentang surat tugas.',
            'tanggal_selesai.*.after_or_equal' => 'Tanggal peserta tidak boleh sebelum rentang surat tugas.',
            'tanggal_selesai.*.before_or_equal' => 'Tanggal peserta tidak boleh melewati rentang surat tugas.',
        ]);
        // Tanggal mulai tidak boleh lebih besar dari tanggal selesai (per peserta)
        foreach ((array) $request->input('tanggal_mulai', []) as $pid => $m) {
            $s = $request->input("tanggal_selesai.$pid");
            if ($m && $s && $m > $s) {
                return back()
                    ->withErrors(['tanggal' => 'Ada peserta yang tanggal mulainya melebihi tanggal selesai.'])
                    ->withInput();
            }
        }

        // Jenis uang harian cuma relevan kalau komponen "lumpsum" dicentang.
        if (!in_array('lumpsum', $validated['komponen_biaya'])) {
            $validated['jenis_uang_harian'] = [];
        }

        $agenda->update([
            'komponen_biaya' => $validated['komponen_biaya'],
            'jenis_uang_harian' => $validated['jenis_uang_harian'] ?? [],
        ]);

        // Peserta sudah ditentukan di step 1 (Buat Agenda). Di sini hanya meng-update
        // rincian biaya untuk peserta yang sudah ter-attach.
        $pegawaiIds = $agenda->pegawai->pluck('id');

        // Ambil hanya digit dari input (jaga-jaga tambahan di server)
        $toInt = fn($v) => $v === null || $v === '' ? 0 : (int) preg_replace('/\D/', '', (string) $v);

        $komponenAktif = $validated['komponen_biaya'];
        $activeUhFields = in_array('lumpsum', $komponenAktif)
            ? array_intersect_key(self::UH_FIELD_MAP, array_flip($validated['jenis_uang_harian'] ?? []))
            : [];

        // peng_riil diproses khusus (multi-entry), jadi dikeluarkan dari field generic.
        $genericSimpleFields = array_diff(
            array_intersect(self::SIMPLE_KOMPONEN_FIELDS, $komponenAktif),
            ['peng_riil']
        );
        $prosesPengRiil = in_array('peng_riil', $komponenAktif);

        // Rate UH dipatok dari SBM sesuai provinsi tujuan agenda. Rate dari client diabaikan.
        $sbmRate = SbmRate::forProvinsi($agenda->tujuan);
        $sbmFlat = SbmFlatRate::current();

        $uhRates = [
            'uh_biasa' => (int) ($sbmRate->uh_biasa ?? 0),
            'uh_biasa_60' => (int) ($sbmRate->uh_biasa_60 ?? 0),
            'uh_fullday' => (int) ($sbmFlat->uh_fullday ?? 0),
            'uh_fullboard' => (int) ($sbmFlat->uh_fullboard ?? 0),
        ];

        $syncData = [];
        foreach ($pegawaiIds as $pegawaiId) {
            $rowData = [];

            // ==== Tanggal dinas per peserta ====
            // null kalau sama dengan rentang agenda, supaya ikut otomatis
            // kalau tanggal agenda diubah.
            $mulai = $request->input("tanggal_mulai.$pegawaiId");
            $selesai = $request->input("tanggal_selesai.$pegawaiId");

            $rowData['tanggal_mulai'] = ($mulai && $mulai !== $min) ? $mulai : null;
            $rowData['tanggal_selesai'] = ($selesai && $selesai !== $max) ? $selesai : null;

            // opsional: kolom lama_hari tetap diisi supaya tidak menggantung
            $rowData['lama_hari'] = (int) Carbon::parse($mulai ?: $min)->startOfDay()
                ->diffInDays(Carbon::parse($selesai ?: $max)->startOfDay()) + 1;

            foreach ($genericSimpleFields as $field) {
                $rowData[$field] = $request->input("$field.$pegawaiId");
            }

            if ($prosesPengRiil) {
                // ==== Peng. Riil multi-entry ====
                // Entry SBM dihitung ULANG di sini dari master peng_riil_rates;
                // entry manual dipercaya nilainya dari client (at cost).
                $rawDetail = $request->input("peng_riil_detail.$pegawaiId");
                $entriesInput = [];

                if ($rawDetail) {
                    $decoded = json_decode($rawDetail, true);
                    if (is_array($decoded)) {
                        $entriesInput = $decoded;
                    }
                }

                $entries = [];
                $total = 0;

                foreach ($entriesInput as $entryInput) {
                    if (!is_array($entryInput)) {
                        continue;
                    }

                    $entryMode = in_array($entryInput['mode'] ?? null, ['sbm', 'manual'], true)
                        ? $entryInput['mode']
                        : 'manual';

                    if ($entryMode === 'sbm') {
                        $rate = PengRiilRate::find($entryInput['rate_id'] ?? null);

                        if (!$rate) {
                            continue; // tujuan tidak dipilih / tidak valid
                        }

                        $nilai = (int) $rate->rate_pp;
                        $keterangan = $rate->kategori === 'jabodetabek'
                            ? 'Transport Jakarta – ' . $rate->tujuan . ' PP'
                            : 'Transport Daerah (' . $rate->tujuan . ') PP';

                        $entries[] = [
                            'mode' => 'sbm',
                            'value' => $nilai,
                            'rate_id' => $rate->id,
                            'tujuan' => $rate->tujuan,
                            'keterangan' => $keterangan,
                        ];
                        $total += $nilai;
                    } else {
                        $nilai = $toInt($entryInput['value'] ?? null);
                        $keterangan = trim((string) ($entryInput['keterangan'] ?? ''));

                        if ($nilai === 0 && $keterangan === '') {
                            continue; // entry manual kosong total
                        }

                        $entries[] = [
                            'mode' => 'manual',
                            'value' => $nilai,
                            'rate_id' => null,
                            'tujuan' => null,
                            'keterangan' => $keterangan,
                        ];
                        $total += $nilai;
                    }
                }

                $rowData['peng_riil'] = $total;
                $rowData['peng_riil_detail'] = $entries ? json_encode($entries) : null;

                // Kolom lama dipertahankan sebagai metadata ringkas dari entry pertama.
                $rowData['peng_riil_mode'] = $entries[0]['mode'] ?? 'manual';
                $rowData['peng_riil_rate_id'] = $entries[0]['rate_id'] ?? null;
            }

            $lumpsumTotal = 0;
            foreach ($activeUhFields as $uhKey => $f) {
                $hari = $toInt($request->input("{$f['hari']}.$pegawaiId"));
                $rate = $uhRates[$uhKey];

                $rowData[$f['hari']] = $hari;
                $rowData[$f['rate']] = $rate;
                $lumpsumTotal += $hari * $rate;
            }

            if (in_array('lumpsum', $komponenAktif)) {
                $rowData['lumpsum'] = $lumpsumTotal;
            }

            // Nol-kan semua kolom biaya yang tidak aktif supaya nilai lama tidak nyangkut di pivot.
            // $rowData menang atas default, jadi komponen aktif tetap pakai nilai barunya.
            $resetDefaults = [];
            foreach (self::SIMPLE_KOMPONEN_FIELDS as $f) {
                $resetDefaults[$f] = 0;
            }
            $resetDefaults['peng_riil'] = 0;
            $resetDefaults['peng_riil_detail'] = null;
            $resetDefaults['lumpsum'] = 0;
            foreach (self::UH_FIELD_MAP as $f) {
                $resetDefaults[$f['hari']] = 0;
                $resetDefaults[$f['rate']] = 0;
            }

            $syncData[$pegawaiId] = array_merge($resetDefaults, $rowData);
        }

        $agenda->pegawai()->sync($syncData);

        // Rincian baru saja berubah: perbarui snapshot nominal memo yang masih outstanding
        // (yang sudah punya nomor memo). Kalau tidak, nominal di daftar memo tertinggal angka lama.
        $this->segarkanSnapshotMemo($agenda);

        // Belum pilih anggaran -> lanjut ke step 3
        if (empty($agenda->mak)) {
            return redirect()->route('agendas.anggaran', $agenda)
                ->with('success', 'Biaya tersimpan. Lanjut pilih anggaran & nomor memo.');
        }

        // Sudah punya MAK: biaya baru bisa melebihi sisa MAK -> peringatan saja (data tetap tersimpan)
        $redirect = redirect()->route('agendas.show', $agenda)
            ->with('success', 'Peserta & biaya berhasil disimpan.');

        $peringatan = MakSisaService::cek($agenda->fresh(), $agenda->mak);

        return $peringatan ? $redirect->with('warning', $peringatan) : $redirect;
    }

    /**
     * Step 3: pilih MAK (setelah total biaya diketahui), isi uraian, petugas
     * verifikasi, nomor memo PNS/Non PNS, dan PIC.
     */
    public function anggaranForm(Agenda $agenda)
    {
        if (empty($agenda->komponen_biaya)) {
            return redirect()->route('agendas.peserta', $agenda)
                ->withErrors(['biaya' => 'Isi rincian biaya dulu sebelum memilih anggaran.']);
        }

        $agenda->load('pegawai');

        $pegawaiList = Pegawai::orderBy('nama')->get();

        // Hanya MAK aktif; MAK yang sedang dipakai agenda ini tetap ikut walau sudah nonaktif.
        $makOptions = MakOption::where(fn($q) => $q->where('is_active', true)->orWhere('mak', $agenda->mak))
            ->orderBy('mak')
            ->get();

        $makOptions = MakUnitService::tandai($makOptions, auth()->user());
        $makOutstandingDetail = MakSisaService::outstandingDetail(null, $agenda->id);
        $makOutstanding = array_map(fn($d) => $d['sendiri'] + $d['lain'], $makOutstandingDetail);
        $totalAsn = (int) $agenda->biaya_asn;
        $totalNonAsn = (int) $agenda->biaya_non_asn;
        $totalBiaya = $totalAsn + $totalNonAsn;

        return view('agendas.anggaran', compact(
            'agenda',
            'pegawaiList',
            'makOptions',
            'makOutstanding',
            'makOutstandingDetail',
            'totalAsn',
            'totalNonAsn',
            'totalBiaya'
        ));
    }

    public function anggaranStore(Request $request, Agenda $agenda)
    {
        $picData = $request->validate(['pic_id' => 'required|exists:pegawai,id']);
        $adminData = $this->validateAdministrasiFields($request, $agenda->uraian_kegiatan);

        $pegawaiIds = $agenda->pegawai()->pluck('pegawai.id')->all();

        // Nomor Memo PNS/Non PNS wajib sesuai status peserta yang dipilih.
        $this->ensureNomorMemoFilled($pegawaiIds, $adminData['nomor_memo_pns'] ?? null, $adminData['nomor_memo_non_pns'] ?? null);

        // Nomor Memo harus unik antar agenda; agenda ini sendiri dikecualikan.
        $this->ensureNomorMemoUnique($adminData['nomor_memo_pns'] ?? null, $adminData['nomor_memo_non_pns'] ?? null, $agenda->id);

        // ---- Kunci: memo yang sudah SAKTI / SP2D tidak boleh ganti MAK atau nomor memo ----
        // (uangnya sudah tercatat di SAKTI; kalau perlu koreksi, mundurkan status memo dulu)
        $terkunciPns = filled($agenda->nomor_memo_pns)
            && in_array($agenda->status_pns, ['sakti', 'sp2d'], true);
        $terkunciNonPns = filled($agenda->nomor_memo_non_pns)
            && in_array($agenda->status_non_pns, ['sakti', 'sp2d'], true);
        $adaTerkunci = $terkunciPns || $terkunciNonPns;

        if ($adaTerkunci) {
            $berubah = $agenda->mak !== ($adminData['mak'] ?? null)
                || ($terkunciPns && $agenda->nomor_memo_pns !== ($adminData['nomor_memo_pns'] ?? null))
                || ($terkunciNonPns && $agenda->nomor_memo_non_pns !== ($adminData['nomor_memo_non_pns'] ?? null));

            if ($berubah) {
                throw ValidationException::withMessages([
                    'mak' => 'MAK dan nomor memo tidak bisa diubah karena memo sudah SAKTI/SP2D. '
                        . 'Mundurkan status memo dulu jika perlu koreksi.',
                ]);
            }
        }

        // Hard block kalau total biaya > sisa MAK (MAK manual di luar master tidak bisa dicek).
        // Dilewati kalau sudah ada memo SAKTI/SP2D: biayanya sudah masuk realisasi master MAK,
        // jadi membandingkannya lagi dengan sisa akan menghitung dua kali.
        if (!$adaTerkunci && ($msg = MakSisaService::cek($agenda, $adminData['mak']))) {
            throw ValidationException::withMessages(['mak' => $msg]);
        }

        // anggaran_at hanya diisi kalau MAK baru / berubah, supaya simpan ulang
        // tidak menggeser agenda lama ke "setelah tanggal laporan FA".
        // (Tidak lagi dipakai MakSisaService, tapi dibiarkan supaya data lama tetap utuh.)
        if ($agenda->mak !== $adminData['mak']) {
            $adminData['anggaran_at'] = now();
        }

        // ---- Snapshot nominal memo: angka tetap saat memo disimpan ----
        // Hanya memo yang masih outstanding yang di-refresh. Memo SAKTI/SP2D dibiarkan,
        // jadi angkanya tidak ikut bergeser kalau rincian biaya diedit belakangan.
        $agenda->load('pegawai');
        $snapshot = [];

        $nomorPns = $adminData['nomor_memo_pns'] ?? null;
        if (!filled($nomorPns)) {
            $snapshot['nominal_memo_pns'] = null;
        } elseif (!$terkunciPns) {
            $snapshot['nominal_memo_pns'] = (int) $agenda->biaya_asn;
        }

        $nomorNonPns = $adminData['nomor_memo_non_pns'] ?? null;
        if (!filled($nomorNonPns)) {
            $snapshot['nominal_memo_non_pns'] = null;
        } elseif (!$terkunciNonPns) {
            $snapshot['nominal_memo_non_pns'] = (int) $agenda->biaya_non_asn;
        }

        // forceFill: kolom snapshot tidak ada di $fillable; semua isi sudah divalidasi di atas.
        $agenda->forceFill(array_merge($picData, $adminData, $snapshot))->save();

        return redirect()->route('agendas.show', $agenda)
            ->with('success', 'Anggaran & nomor memo berhasil disimpan.');
    }

    public function dokumenForm(Agenda $agenda)
    {
        $agenda->load('dokumenUploads');
        $kategoriList = Agenda::KATEGORI_DOKUMEN;

        return view('agendas.dokumen', compact('agenda', 'kategoriList'));
    }

    public function dokumenStore(Request $request, Agenda $agenda)
    {
        $validated = $request->validate([
            'kategori' => 'required|in:' . implode(',', array_keys(Agenda::KATEGORI_DOKUMEN)),
            'file' => 'required|file|mimes:pdf,jpg,jpeg,png|max:10240',
        ]);

        $existing = DokumenUpload::where('agenda_id', $agenda->id)
            ->where('kategori', $validated['kategori'])
            ->first();

        if ($existing) {
            Storage::disk('public')->delete($existing->file_path);
            $existing->delete();
        }

        $path = $request->file('file')->store('dokumen-spj', 'public');

        DokumenUpload::create([
            'agenda_id' => $agenda->id,
            'kategori' => $validated['kategori'],
            'nama_file' => $request->file('file')->getClientOriginalName(),
            'file_path' => $path,
        ]);

        return redirect()->back()
            ->with('success', 'Dokumen berhasil diupload.');
    }

    /**
     * Upload beberapa kategori dokumen sekaligus dalam satu submit.
     * Dipakai oleh kartu "Dokumen Pendukung" di halaman show agenda,
     * biar user gak perlu submit satu-satu per kategori.
     * Input yang diharapkan: files[kategori_key] => UploadedFile (opsional per kategori).
     */
    public function dokumenStoreAll(Request $request, Agenda $agenda)
    {
        $kategoriValid = array_keys(Agenda::KATEGORI_DOKUMEN);

        $validated = $request->validate([
            'files' => 'nullable|array',
            'files.*' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:10240',
        ]);

        $tersimpan = 0;

        foreach ($request->file('files', []) as $kategori => $file) {
            if (!$file || !$file->isValid() || !in_array($kategori, $kategoriValid, true)) {
                continue;
            }

            $existing = DokumenUpload::where('agenda_id', $agenda->id)
                ->where('kategori', $kategori)
                ->first();

            if ($existing) {
                Storage::disk('public')->delete($existing->file_path);
                $existing->delete();
            }

            $path = $file->store('dokumen-spj', 'public');

            DokumenUpload::create([
                'agenda_id' => $agenda->id,
                'kategori' => $kategori,
                'nama_file' => $file->getClientOriginalName(),
                'file_path' => $path,
            ]);

            $tersimpan++;
        }

        $pesan = $tersimpan > 0
            ? "{$tersimpan} dokumen berhasil diupload."
            : 'Tidak ada file yang dipilih untuk diupload.';

        return redirect()->back()->with('success', $pesan);
    }

    public function dokumenDestroy(Agenda $agenda, DokumenUpload $dokumen)
    {
        Storage::disk('public')->delete($dokumen->file_path);
        $dokumen->delete();

        return redirect()->back()
            ->with('success', 'Dokumen berhasil dihapus.');
    }

    // generateSpd(), generateNominatif(), validateMemoStatus() DIPINDAH ke
    // AgendaPdfController — jangan ditambahin lagi di sini, biar gak dobel.

    /**
     * True kalau salah satu memo agenda (yang sudah bernomor) berstatus SAKTI atau SP2D.
     * Memo seperti itu sudah tercatat di SAKTI, jadi nominal, MAK, nomor memo, susunan
     * peserta, dan penghapusan agenda dikunci. Status batal TIDAK ikut mengunci.
     */
    private function adaMemoTerkunci(Agenda $agenda): bool
    {
        return (filled($agenda->nomor_memo_pns) && in_array($agenda->status_pns, ['sakti', 'sp2d'], true))
            || (filled($agenda->nomor_memo_non_pns) && in_array($agenda->status_non_pns, ['sakti', 'sp2d'], true));
    }

    /**
     * Perbarui snapshot nominal untuk memo yang masih outstanding dan sudah bernomor,
     * dihitung dari rincian peserta saat ini. Memo SAKTI/SP2D/batal tidak disentuh.
     */
    private function segarkanSnapshotMemo(Agenda $agenda): void
    {
        $agenda->load('pegawai');
        $snapshot = [];

        if (filled($agenda->nomor_memo_pns) && ($agenda->status_pns ?? 'outstanding') === 'outstanding') {
            $snapshot['nominal_memo_pns'] = (int) $agenda->biaya_asn;
        }

        if (filled($agenda->nomor_memo_non_pns) && ($agenda->status_non_pns ?? 'outstanding') === 'outstanding') {
            $snapshot['nominal_memo_non_pns'] = (int) $agenda->biaya_non_asn;
        }

        if ($snapshot) {
            $agenda->forceFill($snapshot)->save();
        }
    }

    /**
     * Pecah string MAK "7458.ABR.006.075.EE.524119" jadi 4 komponen:
     * kode_giat (3 segmen pertama), kode_komponen, kode_akun_ap, kode_belanja.
     * Return null kalau formatnya gak sesuai (bukan 6 segmen).
     */
    private function parseMak(string $mak): ?array
    {
        $parts = explode('.', $mak);

        if (count($parts) !== 6) {
            return null;
        }

        return [
            'kode_giat' => implode('.', array_slice($parts, 0, 3)), // 7458.ABR.006
            'kode_komponen' => $parts[3],                                // 075
            'kode_akun_ap' => $parts[4],                                // EE
            'kode_belanja' => $parts[5],                                // 524119
        ];
    }

    /**
     * Nomor Memo PNS cuma wajib kalau ada peserta berstatus PNS di antara yang
     * dipilih; Nomor Memo Non PNS cuma wajib kalau ada peserta Non PNS. Kalau
     * dua-duanya ada, dua-duanya wajib. Sama kayak ensureNomorStKaroFilled(),
     * dicek manual karena aturannya tergantung data peserta, bukan field lain.
     */
    private function ensureNomorMemoFilled(array $pegawaiIds, ?string $nomorMemoPns, ?string $nomorMemoNonPns): void
    {
        $statusList = Pegawai::whereIn('id', $pegawaiIds)->pluck('status_kepegawaian');

        $adaPns = $statusList->contains('PNS');
        $adaNonPns = $statusList->contains('Non PNS');

        $errors = [];
        if ($adaPns && empty($nomorMemoPns)) {
            $errors['nomor_memo_pns'] = 'Nomor Memo (PNS) wajib diisi karena ada peserta PNS di agenda ini.';
        }
        if ($adaNonPns && empty($nomorMemoNonPns)) {
            $errors['nomor_memo_non_pns'] = 'Nomor Memo (Non PNS) wajib diisi karena ada peserta Non PNS di agenda ini.';
        }

        if ($errors) {
            throw ValidationException::withMessages($errors);
        }
    }

    /**
     * Nomor memo (PNS / Non PNS) harus unik antar agenda. $ignoreId dipakai saat
     * update supaya agenda itu sendiri tidak dianggap bentrok dengan dirinya.
     * Kalau bentrok, user diminta klik "Ambil Nomor" lagi untuk dapat nomor baru.
     */
    private function ensureNomorMemoUnique(?string $nomorMemoPns, ?string $nomorMemoNonPns, ?int $ignoreId = null): void
    {
        $cek = [
            'nomor_memo_pns' => ['label' => 'Nomor Memo (PNS)', 'nilai' => $nomorMemoPns],
            'nomor_memo_non_pns' => ['label' => 'Nomor Memo (Non PNS)', 'nilai' => $nomorMemoNonPns],
        ];

        $errors = [];

        foreach ($cek as $kolom => $item) {
            if (empty($item['nilai'])) {
                continue;
            }

            $dipakai = NomorMemoService::sudahDipakai($item['nilai'], null, $ignoreId);

            if ($dipakai) {
                $errors[$kolom] = $item['label'] . ' ini sudah dipakai agenda lain. Klik "Ambil Nomor" lagi untuk dapat nomor terbaru.';
            }
        }

        // Kasus khusus: PNS dan Non PNS diisi nomor yang sama di form yang sama
        if (!empty($nomorMemoPns) && $nomorMemoPns === $nomorMemoNonPns) {
            $errors['nomor_memo_non_pns'] = 'Nomor Memo (Non PNS) tidak boleh sama dengan Nomor Memo (PNS).';
        }

        if ($errors) {
            throw ValidationException::withMessages($errors);
        }
    }

    private function ensureNomorStKaroFilled(array $pegawaiIds, ?string $nomorStKaro): void
    {
        $adaEselon = Pegawai::whereIn('id', $pegawaiIds)
            ->whereIn('eselon', Pegawai::ESELON_ST_KHUSUS)
            ->exists();

        if ($adaEselon && empty($nomorStKaro)) {
            throw ValidationException::withMessages([
                'nomor_st_karo' => 'Nomor ST khusus wajib diisi karena ada peserta Eselon I/II di agenda ini.',
            ]);
        }
    }
    /**
     * Field administrasi/anggaran yang dipakai bersama PNS & Non-PNS. Sekarang
     * diisi di step 3 (Anggaran & Memo), setelah total biaya agenda diketahui.
     *
     * $uraianKegiatan dipakai buat nyusun otomatis uraian_memo_pns/non_pns —
     * gak ada input terpisah buat itu, biar gak diketik ulang.
     *
     * Dipakai oleh anggaranStore().
     */
    private function validateAdministrasiFields(Request $request, string $uraianKegiatan): array
    {
        $validated = $request->validate([
            // Wajib format 6 segmen dipisah titik: 7458.ABR.006.075.EE.524119
            'mak' => ['required', 'string', 'regex:/^[^.\s]+\.[^.\s]+\.[^.\s]+\.[^.\s]+\.[^.\s]+\.[^.\s]+$/'],

            'uraian_giat' => 'required|string',
            'uraian_komponen' => 'required|string',
            'uraian_akun_ap' => 'required|string',
            'uraian_belanja' => 'required|string',

            'petugas_verifikasi_id' => 'required|exists:pegawai,id',

            // Nomor memo diisi manual (nomor surat resmi, gak di-generate otomatis).
            // Beda per status karena biasanya emang beda nomor urut (mis. PNS 323,
            // Non PNS 324) — bukan berarti sama.
            // Wajib/enggaknya tergantung status peserta yang dipilih (PNS/Non PNS) —
            // dicek terpisah di ensureNomorMemoFilled(), bukan di sini.
            // Keunikan dicek di ensureNomorMemoUnique().
            'nomor_memo_pns' => 'nullable|string',
            'nomor_memo_non_pns' => 'nullable|string',

            // Klasifikasi/Nilai %/Pagu/Pengajuan SENGAJA gak divalidasi/diminta lagi —
            // belum kepake buat memorandum sementara ini (kolomnya tetap ada di DB,
            // cuma gak diisi lewat form).
        ], [
            'mak.regex' => 'Format MAK harus 6 bagian dipisah titik, contoh: 7458.ABR.006.075.EE.524119',
        ]);

        // Kode giat/komponen/akun/belanja SELALU diturunkan dari MAK di server —
        // preview di form itu readonly & gak dikirim (gak ada atribut "name").
        if (!empty($validated['mak'])) {
            $kodeParts = $this->parseMak($validated['mak']);

            if (!$kodeParts) {
                throw ValidationException::withMessages([
                    'mak' => 'Format MAK tidak valid.',
                ]);
            }

            $validated = array_merge($validated, $kodeParts);
        }

        // Uraian memo bukan input manual — selalu disusun ulang dari uraian_kegiatan
        // tiap kali anggaran disimpan, biar selalu sinkron kalau uraian_kegiatan diedit.
        $validated['uraian_memo_pns'] = 'Sehubungan dengan Perjalanan ASN ' . $uraianKegiatan;
        $validated['uraian_memo_non_pns'] = 'Sehubungan dengan Perjalanan NON ASN ' . $uraianKegiatan;

        return $validated;
    }

    // memorandumForm() & memorandumStore() DIHAPUS — halaman "Isi Data Memorandum"
    // gak dipakai lagi. Nomor Memo (PNS/Non-PNS) diisi manual di step 3
    // (anggaranForm/anggaranStore), Uraian Memo disusun otomatis dari
    // uraian_kegiatan (lihat validateAdministrasiFields() di atas).
    // memorandumPdf() TETAP ADA di AgendaPdfController — itu yang beneran
    // generate PDF-nya, dipanggil dari halaman show agenda.
    //
    // CATATAN: hapus juga 2 route ini dari routes/web.php kalau masih ada:
    //   - GET  agendas/{agenda}/memorandum/{status}        (agendas.memorandum)
    //   - POST agendas/{agenda}/memorandum/{status}         (agendas.memorandum.store)
    // Route agendas.memorandum.pdf (GET) TETAP DIPAKAI (AgendaPdfController@memorandumPdf).
    //
    // memorandumPdf(), generateRincianBiaya(), generatePengeluaranRiil(),
    // generateMergedPdf() SEMUA DIPINDAH ke AgendaPdfController — jangan
    // ditambahin lagi di sini, biar gak dobel.

    public function destroy(Agenda $agenda)
    {
        // Memo yang sudah SAKTI/SP2D sudah tercatat di SAKTI, jadi agendanya tidak boleh dihapus.
        // Kalau memang harus dibatalkan, ubah status memo jadi Batal (dengan alasan) dulu.
        if ($this->adaMemoTerkunci($agenda)) {
            return redirect()->route('agendas.show', $agenda)
                ->with('warning', 'Agenda tidak bisa dihapus karena memo sudah SAKTI/SP2D. '
                    . 'Ubah status memo menjadi Batal terlebih dahulu jika memang dibatalkan.');
        }

        // Hapus dokumen fisik yang terkait biar tidak jadi file sampah
        foreach ($agenda->dokumenUploads as $dokumen) {
            Storage::disk('public')->delete($dokumen->file_path);
        }

        $agenda->delete();

        return redirect()->route('agendas.index')
            ->with('success', 'Agenda berhasil dihapus.');
    }
}